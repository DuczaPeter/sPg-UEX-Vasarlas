# CODEX - kötelező projektmunkamód

## Első olvasás

1. `docs/STATUS.md`
2. `docs/DECISIONS.md`
3. A konkrét feladathoz szükséges egyetlen dokumentum.
4. A teljes HTML csak tényleges kódmódosításnál.

## Projektcél

Egyfájlos, böngészőben futó Star Citizen UEX commodity-beszerzési, konténer-, hajókapacitás- és útvonaltervező fenntartása.

## Nem alku tárgya

- Egyetlen HTML-fájl maradjon a futó alkalmazás.
- Nincs kötelező build pipeline.
- Nincs hiányzó adat kitalálása.
- `scu_buy` a vételi készlet.
- A költségterv és a távolsági sorrend külön fázis.
- Azonos fizikai hely külön termináljai 0 Gm és egy megálló.
- UI-only feladat nem módosíthatja a planner vagy API-logikát.
- Planner/route változásnál frissíteni kell a diagnosztikát és teszteket.
- Módosítás előtt backup, utána verzióemelés.
- A publikus `publish/index.html` mindig a kanonikus új verzió másolata.

## Credit-optimalizálás

- Ne olvasd be automatikusan a teljes 400 KB-os HTML-t.
- Előbb keresd meg a célzott class vagy method nevét.
- CSS-változtatásnál csak a style blokk és érintett markup kell.
- Planner-változtatásnál először a `codex/UEX_LOGIC_CONTRACT.md` és a Planner class.
- Route-változtatásnál először a route/cache dokumentum és a distance methodok.
- Ne futtasd a teljes böngészős tesztet minden apró edit után; a végső változatnál kötelező.

## Kötelező zárójelentés

- módosított fájl teljes neve;
- új verzió;
- érintett logikai réteg;
- futtatott tesztek és eredményük;
- nem ellenőrzött kockázat;
- letölthető vagy commitolt végtermék.
