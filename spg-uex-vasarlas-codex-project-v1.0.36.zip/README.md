# sPg UEX Vásárlás - Codex projektcsomag

Aktuális kanonikus verzió: **V1.0.36**.

Ez a csomag azért készült, hogy a projekt Codexszel később credit-takarékosan, a korábbi döntések elvesztése nélkül folytatható legyen.

## Kezdés Codexben

1. Olvasd el a `CODEX.md` fájlt.
2. Utána a `docs/STATUS.md` és `docs/DECISIONS.md` fájlokat.
3. Csak ezután nyisd meg az `app/sPg UEX Vásárlás V1.0.36.html` fájlt, ha tényleges kódmódosítás szükséges.

## Fő mappák

- `app/` - a kanonikus egyfájlos alkalmazás;
- `publish/` - GitHub Pagesre kész fájlok;
- `docs/` - projektleírás, állapot, döntések, tesztelés és használati útmutató;
- `codex/` - Codexnek szánt feladat- és logikai szerződések;
- `diagnostics/` - utolsó ismert diagnosztikai log;
- `references/` - az Ore Market stílusforrása;
- `evidence/` - vizuális smoke teszt;
- `release/` - kiadási ellenőrzőlista.

## Licenc

MIT. Bárki használhatja, másolhatja, módosíthatja, terjesztheti és értékesítheti a projektet a licencfeltételek megtartásával.
