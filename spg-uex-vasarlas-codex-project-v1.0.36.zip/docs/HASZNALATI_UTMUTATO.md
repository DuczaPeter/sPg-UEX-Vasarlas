# sPg UEX Vásárlás V1.0.36 - rövid használati útmutató

## Mire való?

A program Star Citizen commodityk beszerzését tervezi meg UEX-adatok alapján. Megmutatja, hol érdemes vásárolni, mennyibe kerül a teljes lista, hány megálló és hajóforduló kell, valamint milyen sorrendben érdemes felvenni a rakományt.

## Gyors használat

1. Nyisd meg az `index.html` fájlt vagy a GitHub Pages oldalt.
2. A commodity-kártyákon jelöld ki a szükséges anyagokat.
3. Add meg mindegyiknél a kívánt SCU-mennyiséget.
4. Válaszd ki a hajót.
5. Szükség esetén állíts be rendszert, helytípust, rakodási módot, kiindulási helyet vagy célhelyet.
6. Nyomd meg a **Beszerzési terv készítése** gombot.

## Mit mutat az eredmény?

- **Teljes ár:** a megtervezett vásárlások összege.
- **Megállók:** hány külön fizikai helyre kell menni.
- **Fordulók:** hányszor kell a hajó kapacitása miatt rakományt vinni.
- **Beszerzési helyek:** melyik commodityből mennyit kell venni az adott helyen.
- **Rakodási terv:** fordulónként és megállónként rendezett lista.
- **Kevesebb megállós alternatíva:** egyszerűbb útvonal, amely általában drágább.
- **Útvonaljelölés:** exact, heuristic vagy fallback, attól függően, mennyi UEX távolságadat állt rendelkezésre.

## Fontos beállítások

- **Ismeretlen készlet engedélyezése:** használhat olyan ajánlatot, ahol a UEX nem közöl pontos SCU-készletet. A program ezt jelzi.
- **Távolságoptimalizálás:** a kiválasztott helyeket UEX termináltávolság alapján rendezi.
- **Kiindulási és célhely:** a felvételi sorrendet ezekhez igazítja.
- **Minimum konténerméret:** kizárja azokat a helyeket, amelyek nem támogatják a szükséges konténert.

## Amit érdemes tudni

A UEX közösségi adatforrás. Az árak és készletek eltérhetnek a játékban látható állapottól. A program nem talál ki hiányzó adatot. Az ismeretlen készletet, a hiányzó távolságot és a közelítő útvonalat külön jelzi.

Külön terminálok ugyanazon a fizikai helyen nem számítanak külön megállónak. Ezek között a program 0 Gm távolságot használ.

## Mentés és átvitel

Az **Export** funkció JSON-fájlba menti a kiválasztást, a szűrőket, a hajót és a tervet. Az **Import** funkcióval ez később visszatölthető.

A beállítások és a cache a saját böngésződben tárolódnak. A helyi fájl és a GitHub Pages változat külön tárolót használ.

## Hiba esetén

Nyisd meg a **Log** ablakot, futtasd a **Rendszerellenőrzés** gombot, majd másold ki a teljes diagnosztikát. A hibajelentéshez mindig add meg a teljes HTML-fájlnevet és a verziót.

## Adatforrás és licenc

Adatforrás: UEX API 2.0. Ez egy nem hivatalos Star Citizen közösségi eszköz.

Licenc: MIT. Bárki használhatja, módosíthatja és terjesztheti a programot a licencfeltételek megtartásával.
