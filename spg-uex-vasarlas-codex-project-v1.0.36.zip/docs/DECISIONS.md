# Kötelező projekt-döntések

1. A program egyetlen HTML-fájl marad.
2. Az UEX API-adatok hiányzó részeit nem szabad kitalálni.
3. Pozitív vételi ár a commodity-bevonás fő jele; explicit raw/ore kizárandó.
4. A vételi készlet `scu_buy`, az állapot `status_buy`.
5. Külön terminál-ID ugyanazon fizikai helyen nem külön megálló.
6. Azonos fizikai hely távolsága 0 Gm, UEX kérés nélkül.
7. Sikeres és missing distance 12 órás cache; API/network error 5 perc.
8. A teljes kosár költsége az elsődleges optimum.
9. Azonos teljes árnál a kevesebb megálló nyer.
10. A kevesebb megállós, drágább alternatíva külön jelenik meg.
11. Az útvonalrendezés nem módosít árat, mennyiséget vagy kiválasztott helyet.
12. Exact és heuristic optimalitást külön kell megjeleníteni.
13. Provider Contract v2 használatos.
14. Ore Marketből csak explicit aktív és ismert Q < 500 ajánlat fogadható el.
15. A commodity neve a saját helyén kattintható UEX-link; nem külön gomb.
16. Az eredményfejlécekben a teljes ár mindig az utolsó elem.
17. A commodity-kártyák szövege középre igazított.
18. A commodity-választónak nem lehet saját görgetősávja.
19. Az Ore Market szín- és tipográfiai világát használja, de a teljes külső CSS nem tölthető be vakon.
20. A program nyílt forrású MIT licenccel.
