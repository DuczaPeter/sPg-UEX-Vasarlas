# Architektúra

## Egyfájlos rétegek

A HTML tartalmazza:

- beágyazott CSS;
- statikus markup;
- egy IIFE-be zárt JavaScript alkalmazást.

Fő JavaScript osztályok:

- `Logger` - deduplikált naplózás;
- `Storage` - IndexedDB, localStorage, memory fallback;
- `ApiClient` - UEX HTTP, fallback, retry, timeout;
- `ProviderRegistry` - Provider Contract v2;
- `UexNormalizer` - UEX rekordok stabil modellre alakítása;
- `Planner` - konténer-, készlet- és költségoptimalizálás;
- `App` - állapot, UI, cargo bontás, distance route, export/import, diagnosztika.

## Folyamat

1. snapshot betöltése vagy UEX-frissítés;
2. normalizálás és audit;
3. kiválasztott commodityk részletes frissítése;
4. offer pool és szűrés;
5. exact commodity DP + kosárjelöltek;
6. fő és alternatív terv;
7. cargo fordulók;
8. distance matrix és sorrend;
9. render, mentés és diagnosztika.

## Nyilvános API

A `window.sPgUexVasarlas` objektum kezeli az állapotot, requirements betöltést, route contextet, plan futtatást, provider regisztrációt, exportot és importot.
