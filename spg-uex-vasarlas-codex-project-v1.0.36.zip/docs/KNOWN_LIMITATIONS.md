# Ismert korlátok

- A UEX közösségi adat, ezért a játékbeli ár vagy készlet eltérhet.
- Nagy fizikai helyszámnál az azonos árú route tie-break heurisztikus lehet, miközben a vételár továbbra is exact.
- A GitHub Pages első éles futásán külön ellenőrizni kell az UEX CORS-hozzáférést.
- A böngészőcache originhez kötött; a helyi fájl és a GitHub Pages külön tárolót használ.
- Ore Market és Mission Provider nincs automatikusan csatlakoztatva.
- Az alkalmazás jelenlegi NPC-tervező része SCU-alapú.
