# Provider Contract v2

## Offer provider

```js
{
  id: "egyedi-id",
  kind: "spg-ore-market",
  contractVersion: 2,
  capabilities: {},
  async getOffers(context) { return []; }
}
```

Kötelező Ore Market-szűrés:

- explicit aktív;
- ismert Q;
- Q szigorúan 500 alatt;
- Q 500 kizárva.

## Requirement provider

```js
{
  id: "egyedi-id",
  kind: "spg-mission-provider",
  contractVersion: 2,
  capabilities: {},
  async getRequirements(context) {
    return {
      requirements: [
        { commodityId: 1, quantity: 32, unit: "SCU" }
      ],
      route: {
        originKey: "",
        destinationKey: ""
      },
      metadata: {}
    };
  }
}
```

A requirements közvetlen tömbként is visszaadható. A csomagban a `selection` a `requirements` alternatív neve lehet.
