# UEX útvonal- és távolságkezelés

## Két külön optimum

A beszerzési helyek és mennyiségek kiválasztása költségoptimalizálás. A kiválasztott helyek bejárási sorrendje távolságoptimalizálás. A két fázist külön kell tartani.

## Fizikai hely

Külön terminál-ID nem jelent automatikusan külön megállót. A `physicalLocationKey` rendszer + hely alapján egyesíti a terminálokat. Azonos kulcs esetén 0 Gm.

## Távolságcache

- siker: 12 óra;
- nincs adat: 12 óra;
- API vagy hálózati hiba: 5 perc;
- cache-verzió: 3;
- irányfüggetlen párkulcs;
- in-flight deduplikáció.

## Korlátok

- 100 új kérés egy számításban;
- 6 párhuzamos kérés;
- 12 mátrixcsomópont;
- 9 megállóig exact order;
- felette heuristic order.

## Minősítések

- `exact`: minden szükséges él pontos UEX-adatból, exact sorrendkereséssel;
- `heuristic`: valós távolságadat, de közelítő sorrend;
- `fallback`: hiányzó távolság miatt rendszer/body/place szerinti rendezés is részt vett;
- `incomplete`: nem állt rendelkezésre minden szükséges információ.

A diagnosztikában mindig külön szerepeljen a vételár-optimalitás és az útvonal-optimalitás.
