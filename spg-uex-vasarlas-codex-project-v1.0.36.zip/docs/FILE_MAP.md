# Fájltérkép

- `app/sPg UEX Vásárlás V1.0.36.html`: kanonikus forrás.
- `publish/index.html`: GitHub Pages belépési pont.
- `CODEX.md`: Codex kötelező munkamód.
- `docs/STATUS.md`: aktuális állapot.
- `docs/DECISIONS.md`: nem felülírható döntések.
- `docs/UEX_LOGIC_SPEC.md`: teljes UEX logikai szerződés.
- `docs/ROUTE_AND_CACHE.md`: távolság és cache.
- `docs/TESTING.md`: tesztmátrix.
- `codex/HANDOFF.md`: új Codex-folyamat indítása.
- `diagnostics/`: utolsó log.
- `references/Ore Market style.css`: vizuális forrás.
- `evidence/`: smoke screenshot.
