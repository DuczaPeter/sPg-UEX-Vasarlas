# Aktuális állapot

## Kanonikus verzió

`sPg UEX Vásárlás V1.0.36.html`

- app version: 1.0.36
- schema: 13
- Provider Contract: 2
- egyfájlos HTML
- GitHub Pagesre előkészítve
- MIT licenc

## Működő fő funkciók

- UEX API 2.0 snapshot és részletes commodity-frissítés;
- több commodity együttes kiválasztása;
- SCU-igények;
- rendszer-, égitest-, hely- és rakodási szűrők;
- hajókapacitás és támogatott konténerméretek;
- pontos commodity-költség DP;
- kosárszintű helyrészhalmaz-keresés;
- fő, legolcsóbb terv;
- kevesebb megállós alternatíva;
- fordulónkénti rakodási terv;
- origin és destination útvonalkontextus;
- UEX termináltávolság-cache;
- exact, heuristic és fallback útvonaljelölés;
- export/import;
- diagnosztikai log és self-test;
- Provider Contract v2 előkészítve;
- közvetlen UEX commodity-linkek;
- Ore Market vizuális stílus;
- kártyás, belső görgetősáv nélküli commodity-választó.

## Utolsó diagnosztikai állapot

A mellékelt V1.0.36 logban:

- nincs API failure;
- nincs retry;
- a terv elkészül;
- a pontos költségsolver működik;
- a nagy helyszám miatt a route tie-break heurisztikus lehet;
- a distance cache működik;
- azonos fizikai hely párok 0 Gm-ként kezeltek.

## Előkészített, de nincs bekötve

- sPg Ore Market offer provider;
- Mission Provider requirement provider;
- konténerszín mapping külső forrásból.

## Következő verzió

A következő módosított fájl neve `sPg UEX Vásárlás V1.0.37.html` legyen. A V1.0.36-ot backupként meg kell őrizni.
