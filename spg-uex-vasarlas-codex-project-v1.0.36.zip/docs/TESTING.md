# Tesztmátrix

## Statikus

- JavaScript szintaxis hibamentes.
- Nincs duplikált HTML ID.
- A verzió minden diagnosztikai ponton egyezik.
- Nincs beégetett token vagy helyi Windows-útvonal.

## Planner

- egy commodity, egy pontos készlet;
- több commodity, több terminál;
- konténerméret miatti túlvásárlás;
- részleges készlet több helyről;
- megerősített out-of-stock kizárása;
- ismeretlen készlet tiltva és engedve;
- azonos ár, kevesebb megálló;
- azonos ár és megálló, kevesebb tranzakció;
- hajókapacitás miatti több forduló;
- részleges terv helyes hiányprofillal.

## Route

- azonos physicalLocationKey = 0 Gm, kérés nélkül;
- sikeres távolság 12 órás cache;
- missing 12 órás cache;
- error 5 perces cache;
- exact sorrend 9 megállóig;
- heuristic 10 vagy több megállónál;
- origin és destination kezelése;
- fallback route hiányzó éllel;
- a route nem módosítja az árat és mennyiséget.

## Provider

- hibás kind elutasítva;
- hibás contractVersion elutasítva;
- inaktív Ore Market ajánlat elutasítva;
- ismeretlen Q elutasítva;
- Q 499 elfogadható;
- Q 500 elutasítva;
- requirement package route-tal betölthető.

## Release

- Chromium smoke test;
- beépített self-test;
- export/import;
- cache újratöltés után megmarad;
- HTTPS GitHub Pages alatt UEX CORS próba;
- mobil és 110 százalékos nagyítás vizuális ellenőrzése;
- commodity-választó saját görgetősáv nélkül.
