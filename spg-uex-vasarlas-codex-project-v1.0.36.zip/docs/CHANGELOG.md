# Rövid változásnapló

## V1.0.36

- Commodity-kártyák tömörítése.
- Belső görgetősáv nélküli választó.
- Kisebb fölösleges üres hely, középre igazított teljes név.

## V1.0.35

- Commodity-kártyák és szövegek középre igazítása.
- Eredménykapszulák nagyítása.
- A teljes ár minden eredménysorban az utolsó elem.

## V1.0.34

- Ore Market vizuális stílus átvétele.
- Roboto és Orbitron tipográfia.
- Egységes panelek, gombok és modális ablakok.

## V1.0.33

- Tömör, teljes szélességű eredményfelület.
- Részletek alapból összecsukva.

## V1.0.32

- Rendszerenkénti legjobb terv összegzése.

## V1.0.31

- Összecsukott tervkártyákban megálló, rendszer, ár és kapacitás.

## V1.0.30

- Azonos fizikai hely külön termináljai 0 Gm.

## V1.0.29

- Kattintható UEX commodity-nevek.

## V1.0.28

- Provider Contract v2 és jövőbeli integrációs pontok.

## V1.0.27

- Távolságcache és fallback útvonalkezelés.
