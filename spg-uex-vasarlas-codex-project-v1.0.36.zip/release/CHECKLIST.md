# Release ellenőrzőlista

- [ ] Kanonikus fájl új verziószámmal.
- [ ] Előző verzió backupja megvan.
- [ ] `publish/index.html` az új kanonikus fájl másolata.
- [ ] JavaScript szintaxis rendben.
- [ ] Nincs duplikált HTML ID.
- [ ] Beépített self-test sikeres.
- [ ] Chromium smoke test sikeres.
- [ ] Planner-változásnál exact/heuristic audit ellenőrizve.
- [ ] Route-változásnál cache, 0 Gm és fallback tesztelve.
- [ ] UI-változásnál 100 és 110 százalékos nagyítás ellenőrizve.
- [ ] Commodity-választón nincs saját görgetősáv.
- [ ] Mobil tördelés rendben.
- [ ] Export/import működik.
- [ ] README és changelog frissítve.
- [ ] GitHub Pages HTTPS és CORS próba.
