# Codex handoff

## Feladatindítási sablon

Dolgozz a `sPg UEX Vásárlás` projekten. Először olvasd el a `CODEX.md`, `docs/STATUS.md` és `docs/DECISIONS.md` fájlokat. A jelenlegi kanonikus forrás az `app/sPg UEX Vásárlás V1.0.36.html`. Tartsd meg az egyfájlos HTML-szerkezetet. Ne találj ki UEX-adatot. Módosítás előtt készíts backupot, az új fájl verziója V1.0.37 legyen. Csak a feladathoz szükséges kódrészt olvasd be. A végén futtasd a releváns teszteket, frissítsd a `publish/index.html` fájlt, és írd le pontosan, mit ellenőriztél.

## UI-only feladat

Ne módosítsd az `ApiClient`, `UexNormalizer`, `Planner`, distance cache vagy provider logikát.

## Planner vagy route feladat

Előbb olvasd el a `docs/UEX_LOGIC_SPEC.md` és a megfelelő route/provider dokumentumot. A teljesítmény- és optimalitási diagnosztika nem veszhet el.

## Kiadás

A publikus csomagban az `index.html`, `README.md`, `LICENSE` és `.nojekyll` legyen. Az `index.html` bitazonos másolata legyen a kanonikus verziónak.
