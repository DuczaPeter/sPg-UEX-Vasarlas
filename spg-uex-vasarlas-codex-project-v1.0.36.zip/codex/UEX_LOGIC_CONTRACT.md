# UEX beszerzési és útvonaltervezési logika

Ez a dokumentum a `sPg UEX Vásárlás V1.0.36` alkalmazásban kialakított, UEX-specifikus beszerzési és útvonaltervezési működés kötelező logikai szerződése.

## 1. Cél

A bemenet egy vagy több Star Citizen commodity és az igényelt SCU-mennyiség. A rendszer UEX API-adatokból olyan beszerzési tervet készít, amely:

1. először a teljes igény lefedését maximalizálja;
2. teljes lefedés esetén a tényleges teljes vételárat minimalizálja;
3. azonos árnál a megállók számát csökkenti;
4. azonos megállószámnál a tranzakciók számát csökkenti;
5. figyelembe veszi a hajó kapacitását, a készletet és a támogatott konténerméreteket;
6. a rakodási terv elkészítése után a UEX termináltávolságok alapján rendezi a felvételi sorrendet;
7. a legolcsóbb terv mellett külön, kevesebb megállós alternatívát is adhat.

A vételár-optimalizálás és a fizikai útvonalsorrend két külön lépés. Az útvonalrendezés nem írhatja át a már kiválasztott mennyiséget, árat vagy beszerzési helyeket.

## 2. UEX adatforrások

Alap API-címek, sorrendben:

- `https://api.uexcorp.uk/2.0`
- `https://api.uexcorp.space/2.0`

A teljes adatfrissítés által használt erőforrások:

- `game_versions`
- `commodities`
- `commodities_prices_all`
- `terminals`
- `commodities_status`
- `vehicles`

A kiválasztott commoditykhez részletes árlekérés használható. A vételi készlethez mindig a `price_buy` párját, a `scu_buy` mezőt kell használni. A készletállapot a `status_buy`.

## 3. API-hibatűrés

- Kérésenként 30 másodperces timeout.
- API-alapcím fallback támogatott.
- Egy újrapróbálás csak timeout, HTTP 429 vagy 5xx esetén.
- A működő, korábban validált snapshotot sikertelen frissítéskor nem szabad felülírni.
- A token opcionális. Nem kerülhet beégetve a forrásba.
- Böngészőből `mode: cors`, `cache: no-store` használatos.

## 4. Normalizált alapmodellek

### Commodity

Kötelezően megőrzendő fő mezők:

- `id`, `uuid`, `name`, `code`, `slug`, `kind`
- `isLive`, `isAvailable`, `isVisible`, `isBuyable`
- `isRefined`, `isRaw`, `rawFlagKnown`, `refinedFlagKnown`
- `isMineral`, `isHarvestable`, `isFuel`, `isIllegal`
- `modified`, `isFallback`

Pozitív vételi árrekord esetén hiányzó commodity-metaadatból fallback commodity készíthető. Hiányzó adatot ettől függetlenül nem szabad kitalálni.

### Terminal

Fő mezők:

- `id`, `name`, `canonical`, `type`
- `system`, `body`, `place`
- `planet`, `moon`, `station`, `outpost`, `city`, `poi`
- `locationType`
- `freight`, `dock`, `docking`, `autoLoad`, `maxContainer`
- `isLive`, `isVisible`, `gameVersion`, `modified`

Ha az árrekord terminálja hiányzik a terminállistából, az árrekord helymezőiből fallback terminál készíthető, és ezt auditálni kell.

### Price / offer

Fő mezők:

- `commodityId`, `terminalId`
- `price` a `price_buy` mezőből
- `stock` a `scu_buy` mezőből
- `stockStatus` a `status_buy` mezőből
- `compatibleContainers` a `container_sizes` mezőből
- `modified`, `gameVersion`
- normalizált helyadatok és `physicalLocationKey`

### Vehicle

Fő mezők:

- `id`, `name`, `shortName`
- `scu`
- támogatott `containers`
- `loadingDock`, `pad`, `manufacturer`
- concept járművek kizárva

## 5. Commodity-bevonási szabály

- Csak pozitív vételi árral rendelkező sor használható.
- Az explicit raw/ore rekordokat ki kell zárni az NPC-vásárlási tervezőből.
- A gemstone, harvestable és jóváhagyott kereskedelmi commodity maradhat.
- A pozitív árrekord felülírhat elavult `isLive/isAvailable/isVisible/isBuyable` flaget, de ezt auditálni kell.
- Ismeretlen commodity- vagy terminálmetaadat fallbackként megőrizhető, de jelölni kell.

## 6. Fizikai hely azonosítása

A különböző terminálazonosítók ugyanahhoz a fizikai helyhez tartozhatnak.

A fizikai kulcs:

`normalizált-rendszer | normalizált-hely`

Normalizálás:

- kisbetű;
- ékezetek eltávolítása;
- záró `station` vagy `space station` eltávolítása;
- nem alfanumerikus karakterek kötőjelre cserélése;
- szélső kötőjelek levágása.

Ha két pont `physicalLocationKey` értéke azonos, a távolság kötelezően 0 Gm. Ehhez nem szabad UEX távolsági kérést indítani.

## 7. Készletértelmezés

- `stockStatus === 1`: megerősített készlethiány, az ajánlat nem használható.
- `stock > 0`: pontos, megerősített készlet.
- Nem out-of-stock és nincs pozitív stock: ismeretlen mennyiség.
- Ismeretlen készlet csak akkor használható, ha az alkalmazás vagy a hívó ezt kifejezetten engedélyezi.
- `containerCompatible === false`: az ajánlat nem használható.
- Árnak pozitívnak kell lennie.

## 8. Szűrők

Támogatott szűrések:

- helytípus: bolygó, hold, felszín, állomás vagy bármely;
- rendszer;
- égitest;
- konkrét hely;
- rakodás: freight elevator, loading dock, bármelyik;
- minimális konténerméret;
- hajó loading dock képessége.

A szűrés után maradó ajánlatokat stabilan kell rendezni:

1. alacsonyabb egységár;
2. ismert készlet az ismeretlen előtt;
3. frissebb módosítás;
4. fizikai hely kulcsa;
5. terminálazonosító.

## 9. Konténerhelyes mennyiség

A kívánt mennyiséget csak az adott ajánlat támogatott konténerméreteiből lehet összeállítani.

- Egész SCU-méreteknél skála 1.
- Tizedes méretnél skála 100.
- Dinamikus reachability tábla keresi a legkisebb elérhető mennyiséget, amely legalább lefedi az igényt.
- Ha nincs teljes lefedés, a legnagyobb elérhető részleges mennyiség választható.
- Pontos készlet felső korlát.
- Ismeretlen készletnél a szükséges keresési korlát használható, de az eredmény figyelmeztetést kap.
- Meg kell őrizni a konkrét konténerkombinációt, a túlvásárlást és a lefedett mennyiséget.

## 10. Pontos commodity-költségoptimalizálás

Minden commodity külön, typed-array dinamikus programozással optimalizálható.

Állapotcél:

1. a kért mennyiség lefedése, vagy részleges esetben a legnagyobb lefedés;
2. legalacsonyabb tényleges költség;
3. kevesebb fizikai hely;
4. kevesebb tranzakció;
5. kevesebb ismeretlen készlet;
6. frissebb legöregebb adat;
7. stabil aláírás szerinti sorrend.

A kosár pontos árminimuma a commoditynkénti pontos tervek összege. Ettől függetlenül az azonos árú kosárváltozatok között még külön útvonal- és megállószám-tie-break szükséges.

A jelenlegi motor neve: `typed-array-dp-v2`.

## 11. Kosárszintű jelöltek

A tervező több jelöltet állít elő:

- pontos commodity-költségterv;
- egyszerű legolcsóbb baseline;
- praktikus terv;
- egyetlen fizikai helyből készíthető tervek;
- fizikai helyrészhalmazok keresése.

### Helyrészhalmaz-keresés

- 14 vagy kevesebb releváns fizikai helynél teljes kombinációs keresés lehetséges.
- Nagyobb térnél adaptív, több mélységű beam search.
- Aktuális beam width: 420.
- A keresés auditálja a vizsgált helyeket, subseteket, teljes és részleges terveket, a truncation állapotát és a maximális keresett megállószámot.
- A pontos vételár akkor is bizonyított lehet, ha az azonos árú helyválasztás tie-breakje heurisztikus.

## 12. Fő terv rangsorolása

Teljes tervek mindig megelőzik a részleges terveket.

Fő sorrend:

1. teljes lefedés vagy jobb hiányprofil;
2. alacsonyabb teljes költség;
3. kevesebb megálló;
4. kevesebb tranzakció;
5. kevesebb hajóforduló;
6. kevesebb ismeretlen készlet;
7. kisebb túlvásárlás;
8. frissebb legöregebb adat;
9. stabil aláírás.

A kevesebb megállós alternatívánál előbb a megállók száma, utána az ár dönt, de az alternatíva csak azonos lefedési profillal jelenhet meg.

## 13. Hajókapacitás és rakodási terv

A kiválasztott tranzakciókat hajófordulókra kell bontani.

- Egy forduló terhe nem lépheti túl a hajó SCU-kapacitását.
- A konténereket és tranzakciókat nem szabad elveszíteni vagy duplikálni.
- Minden fordulóban meg kell őrizni a helyeket, anyagokat, mennyiségeket és költségeket.
- A terv auditálja a kért, vásárolt, lefedett és túlvásárolt mennyiséget.
- A cargo plan elkészítése után fut a távolsági sorrendezés.

## 14. UEX termináltávolság és cache

Cache-verzió: 3.

TTL:

- sikeres távolság: 12 óra;
- valós, adat nélküli válasz: 12 óra;
- hálózati vagy API-hiba: 5 perc.

Fontos különbség: az adat nélküli válasz nem azonos a hálózati hibával.

További szabályok:

- azonos fizikai hely: 0 Gm, API-hívás nélkül;
- párkulcs irányfüggetlen;
- in-flight kérés deduplikálható;
- számításonként legfeljebb 100 új távolsági kérés;
- konkurencia: 6;
- legfeljebb 12 csomópontos távolságmátrix;
- 9 vagy kevesebb rendezendő megállónál pontos sorrendkeresés;
- nagyobb listánál heurisztikus nearest-neighbor és javító lépések;
- hiányzó élek esetén rendszer/body/place fallback sorrend használható, de az eredményt heurisztikusként vagy fallbackként kell jelölni.

## 15. Kiindulási és célhely

Az útvonal kontextusa opcionálisan tartalmazhat:

- `originKey` vagy teljes `origin` objektum;
- `destinationKey` vagy teljes `destination` objektum.

A kiindulási és célhely nem feltétlenül beszerzési terminál. Külső helypont is használható, ha a rendszer, hely és lehetőség szerint a terminálazonosító rendelkezésre áll.

A célhely csak a sorrendet befolyásolja. Nem válhat vásárlási megállóvá, ha ott nincs kiválasztott tranzakció.

## 16. Provider Contract v2

### Offer provider

- `kind: "spg-ore-market"`
- `contractVersion: 2`
- `getOffers(context)` függvény

Ore Marketből csak olyan ajánlat fogadható el, amely:

- explicit aktív;
- minősége ismert;
- `quality < 500`;
- a `quality === 500` már kizárt.

### Requirement provider

- `kind: "spg-mission-provider"`
- `contractVersion: 2`
- `getRequirements(context)` függvény

A válasz lehet közvetlen requirements tömb vagy csomag:

- `requirements` vagy `selection`;
- opcionális `route`;
- opcionális `metadata`.

A route tartalmazhat origin és destination helyet.

## 17. Kötelező audit és diagnosztika

Minden tervnél legyen ellenőrizhető:

- API-kérések, sikerek, hibák, retryk;
- snapshot forrás és időpont;
- felhasznált ajánlatok száma;
- teljes vagy részleges lefedés;
- kért, vásárolt, lefedett és túlvásárolt SCU;
- újraszámolt költség egyezése;
- megállók, tranzakciók, fordulók;
- ismert és ismeretlen készletek;
- konténerkombinációk;
- exact vagy heuristic költségoptimalitás;
- exact, heuristic vagy fallback útvonal;
- távolságcache statisztika;
- same-location 0 Gm párok;
- subset keresés korlátai;
- hiányzó anyagok és lehetséges szűrőlazítások.

## 18. Nem megengedett egyszerűsítések

- Nem szabad csak a legolcsóbb egységárat kiválasztani konténer és stock nélkül.
- Nem szabad a `scu_sell_stock` mezőt vételi készletként használni.
- Nem szabad külön terminálazonosítót automatikusan külön fizikai megállónak tekinteni.
- Nem szabad hiányzó távolságot 0-nak vagy kitalált számmal helyettesíteni.
- Nem szabad az útvonalrendezéssel megváltoztatni a költségtervet.
- Nem szabad ismeretlen készletet biztos készletként megjeleníteni.
- Nem szabad pontos optimumnak nevezni azt, ami csak heurisztikus.
- Nem szabad a Q 500 Ore Market-ajánlatot elfogadni.

## 19. Stabilitási követelmény

Azonos bemenet és azonos snapshot mellett az eredmény determinisztikus legyen. Az utolsó tie-break mindig stabil hely-, terminál- vagy aláírássorrend legyen.
