# Credit-optimalizált Codex munkafolyamat

## Olvasási sorrend

1. Először csak ezt a fájlt és a `SKILL.md` vagy `CODEX.md` fájlt olvasd el.
2. Csak a konkrét feladathoz szükséges referenciafájlt nyisd meg.
3. A teljes V1.0.36 HTML-t csak akkor olvasd végig, ha tényleges kódmódosítás vagy regresszió-összehasonlítás szükséges.
4. A diagnosztikai JSON-t csak adat-, számítási vagy teljesítményhiba vizsgálatakor töltsd be.

## Feladattípus szerinti minimális kontextus

- API vagy normalizálás: `API_AND_DATA.md` + `reference-code/UexNormalizer.js`.
- Költségoptimalizálás: `UEX_LOGIC_SPEC.md` + `reference-code/Planner.js`.
- Távolság vagy útvonal: `ROUTE_AND_CACHE.md` + `reference-code/distance-routing-methods.js`.
- Provider integráció: `PROVIDER_CONTRACT_V2.md` + `reference-code/ProviderRegistry.js`.
- UI-only változtatás: ne töltsd be a Planner vagy distance referenciafájlokat.
- Projektfolytatás: `STATUS.md`, `DECISIONS.md`, majd csak a módosítandó forrásrész.

## Módosítási szabályok

- Először állapítsd meg, hogy a feladat UI, adat, planner, route, provider vagy release jellegű.
- Ne írj újra működő modult csak stílus- vagy szövegmódosítás miatt.
- A jelenlegi egyfájlos HTML-szerkezetet tartsd meg, hacsak a felhasználó kifejezetten mást nem kér.
- Minden módosítás előtt készíts verziózott backupot.
- Új kiadásnál emeld a verziót, és a publikus `index.html` legyen az új verzió másolata.
- Ne találj ki UEX mezőt, készletet, távolságot vagy játékszabályt.
- Ha a feladat nem egyértelmű, egyetlen pontosító kérdést tegyél fel.

## Tesztlépcsők

A legolcsóbb ellenőrzéstől haladj a drágább felé:

1. statikus szintaxis és duplikált HTML ID;
2. célzott egység- vagy fixture teszt;
3. beépített self-test;
4. Chromium smoke test;
5. csak API-t érintő változásnál élő UEX-frissítés;
6. csak kiadásnál GitHub Pages HTTPS/CORS próba.

Ne futtasd újra az összes drága tesztet minden apró CSS-módosítás után. A végső kiadás előtt viszont fusson a teljes elfogadási lista.

## Kimeneti fegyelem

- A felhasználónak egy végleges eredményt adj.
- A hibát és a nem ellenőrzött részt mondd ki egyértelműen.
- Ne állíts sikeres tesztet, ha nem futott le.
- Fájlhivatkozásnál teljes fájlnevet használj, ne belső sorszámot.
