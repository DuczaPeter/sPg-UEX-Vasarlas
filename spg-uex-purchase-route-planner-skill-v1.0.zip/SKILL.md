---
name: spg-uex-purchase-route-planner
description: UEX API-alapú Star Citizen commodity-beszerzési, konténer-, készlet-, hajókapacitás- és termináltávolság-optimalizálás átvitele vagy javítása más projektben. Használd, amikor a feladat a sPg UEX Vásárlásban kialakított keresési, vásárlási, rakodási vagy útvonaltervezési logikát igényli. Ne használd pusztán UI-stílus vagy általános, nem UEX-es kereskedelmi feladathoz.
---

# sPg UEX Purchase & Route Planner

## Cél

Ez a skill a `sPg UEX Vásárlás V1.0.36` UEX-specifikus keresési és útvonaltervezési logikáját teszi újrahasználhatóvá. Egy másik projektnek átadható anélkül, hogy a teljes eredeti fejlesztési beszélgetést újra kellene építeni.

## Első lépés

A feladatot sorold be:

- UEX API és normalizálás;
- commodity-költségoptimalizálás;
- konténer és készlet;
- hajókapacitás és fordulók;
- termináltávolság és útvonal;
- provider integráció;
- diagnosztika vagy regresszió.

Ezután csak a megfelelő referenciafájlt olvasd el. A teljes referenciaalkalmazást csak konkrét kódátültetésnél nyisd meg.

## Kötelező működés

1. A vételi készlet a `scu_buy`, nem a sell stock.
2. A konténerméret, stock és hajókapacitás kötelező korlát.
3. A teljes lefedés elsődleges; utána a teljes ár minimalizálása.
4. Azonos árnál kevesebb fizikai megálló nyer.
5. Külön terminál-ID ugyanazon helyen 0 Gm és egy fizikai megálló.
6. Az útvonalrendezés nem írhatja át a vásárlási tervet.
7. Missing distance és API error külön cache-kategória.
8. Exact és heuristic eredményt világosan meg kell különböztetni.
9. Hiányzó adatot nem szabad kitalálni.
10. Ore Market providerből csak explicit aktív, ismert Q < 500 ajánlat fogadható el.

## Credit-optimalizált olvasás

- API: `references/API_AND_DATA.md`
- Planner: `references/UEX_LOGIC_SPEC.md`
- Route: `references/ROUTE_AND_CACHE.md`
- Provider: `references/PROVIDER_CONTRACT_V2.md`
- Teszt: `references/TEST_MATRIX.md`
- Munkamódszer: `references/CREDIT_OPTIMIZED_WORKFLOW.md`
- Pontos kódátültetés: `reference-code/`
- Végső összehasonlítás: `reference-app/sPg UEX Vásárlás V1.0.36.html`

## Végrehajtási sorrend

1. Azonosítsd a célprojekt adatmodelljét és a már meglévő UEX-hívásokat.
2. Készíts mezőtérképet a célmodell és a normalizált modellek között.
3. Először a fixture-adatokkal működő planner magot építsd be.
4. Ezután kösd rá az API-normalizálást és snapshotkezelést.
5. Külön lépésben add hozzá a cargo bontást.
6. Utolsóként add hozzá a termináltávolságokat és cache-t.
7. Futtasd a célzott teszteket, majd a teljes elfogadási listát.
8. Dokumentáld, mely eredmény exact és mely heuristic.

## Tilos

- Ne egyszerűsítsd le a problémát puszta egységár-rendezésre.
- Ne keverd össze a beszerzési optimumot az útvonalsorrenddel.
- Ne kezeld külön megállóként ugyanazon fizikai hely termináljait.
- Ne használj hosszú TTL-t valós hálózati hibára.
- Ne állíts matematikailag bizonyított optimumot heurisztikus keresésre.
- Ne olvasd végig automatikusan az összes referenciafájlt.

## Végső ellenőrzés

A válasz vagy a módosítás végén röviden írd le:

- melyik logikai réteg változott;
- melyik réteget hagytad érintetlenül;
- mely tesztek futottak le;
- exact vagy heuristic maradt-e az eredmény;
- maradt-e nem ellenőrzött kockázat.
