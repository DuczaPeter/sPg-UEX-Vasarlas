# UEX API és adatnormalizálás

## Elsődleges erőforrások

`game_versions`, `commodities`, `commodities_prices_all`, `terminals`, `commodities_status`, `vehicles`.

## Kritikus mezőpárok

- vételi ár: `price_buy`;
- vételi készlet: `scu_buy`;
- vételi állapot: `status_buy`;
- konténerméretek: `container_sizes`.

A `scu_sell_stock` nem használható vételi készletként.

## Snapshot szabály

Az új snapshot csak teljes normalizálás és validáció után írhatja felül a korábbit. Sikertelen frissítésnél a régi snapshot marad aktív.

## Fallback rekord

Pozitív árrekordból hiányzó commodity vagy terminál metaadata visszaállítható a rekord saját mezőiből. A fallback státuszt és a hiányt auditálni kell. Nem szabad ismeretlen mezőt kitalálni.
