# Forrásverzió

A skill kanonikus forrása: `sPg UEX Vásárlás V1.0.36`, schema 13, Provider Contract v2.
