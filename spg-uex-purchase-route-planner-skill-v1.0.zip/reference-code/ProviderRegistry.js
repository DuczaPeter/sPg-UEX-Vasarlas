class ProviderRegistry {
    constructor(log, contractVersion) {
      this.log = log;
      this.contractVersion = contractVersion;
      this.offerProviders = new Map();
      this.requirementProviders = new Map();
    }
    validateProvider(type, p) {
      const errors = [], expectedKind = type === "offer" ? "spg-ore-market" : "spg-mission-provider",
        method = type === "offer" ? "getOffers" : "getRequirements";
      if (!p || typeof p !== "object") errors.push("A provider nem objektum.");
      if (!text(p?.id).trim()) errors.push("Hiányzó provider id.");
      if (p?.kind !== expectedKind) errors.push(`A provider kind értéke csak ${expectedKind} lehet.`);
      if (Number(p?.contractVersion) !== Number(this.contractVersion))
        errors.push(`Provider contract eltérés: v${p?.contractVersion ?? "?"}, szükséges v${this.contractVersion}.`);
      if (typeof p?.[method] !== "function") errors.push(`Hiányzó ${method} függvény.`);
      return { ok: errors.length === 0, type, expectedKind, contractVersion: this.contractVersion, id: text(p?.id).trim() || null, errors };
    }
    registerOffer(p) {
      const validation = this.validateProvider("offer", p);
      if (!validation.ok) throw new Error(`Érvénytelen offer provider: ${validation.errors.join(" ")}`);
      if (this.offerProviders.has(validation.id)) throw new Error(`Már létezik ilyen offer provider: ${validation.id}`);
      this.offerProviders.set(validation.id, p);
      this.log.info("Provider", `Ajánlatprovider csatlakoztatva: ${validation.id}`, { kind: p.kind, contractVersion: p.contractVersion, capabilities: p.capabilities || {} });
      return () => this.offerProviders.delete(validation.id);
    }
    registerRequirement(p) {
      const validation = this.validateProvider("requirement", p);
      if (!validation.ok) throw new Error(`Érvénytelen requirement provider: ${validation.errors.join(" ")}`);
      if (this.requirementProviders.has(validation.id)) throw new Error(`Már létezik ilyen requirement provider: ${validation.id}`);
      this.requirementProviders.set(validation.id, p);
      this.log.info("Provider", `Igényprovider csatlakoztatva: ${validation.id}`, { kind: p.kind, contractVersion: p.contractVersion, capabilities: p.capabilities || {} });
      return () => this.requirementProviders.delete(validation.id);
    }
    describe() {
      return {
        contractVersion: this.contractVersion,
        offers: [...this.offerProviders.values()].map((p) => ({ id: p.id, kind: p.kind, contractVersion: p.contractVersion, capabilities: clone(p.capabilities || {}) })),
        requirements: [...this.requirementProviders.values()].map((p) => ({ id: p.id, kind: p.kind, contractVersion: p.contractVersion, capabilities: clone(p.capabilities || {}) })),
      };
    }
    async externalOffers(ctx) {
      const out = [];
      for (const p of this.offerProviders.values()) {
        let rejectedInactive = 0, rejectedQuality = 0, rejectedShape = 0;
        try {
          const payload = await p.getOffers(clone(ctx)), rows = Array.isArray(payload) ? payload : [];
          if (!Array.isArray(payload)) throw new Error("Az offer provider válasza nem tömb.");
          for (const r of rows.slice(0, 5000)) {
            if (!r || typeof r !== "object") { rejectedShape++; continue; }
            if (p.kind === "spg-ore-market") {
              const active = r.active === true || r.isActive === true || r.is_active === true || lower(r.status) === "active",
                q = num(r.quality);
              if (!active) { rejectedInactive++; continue; }
              if (!(q !== null && q < 500)) { rejectedQuality++; continue; }
            }
            out.push({ ...r, providerId: p.id, sourceKind: p.kind || "external" });
          }
          if (rejectedInactive || rejectedQuality || rejectedShape)
            this.log.info("Provider", `Külső ajánlatok szerződés szerinti szűrése: ${p.id}`, { accepted: out.filter((x) => x.providerId === p.id).length, rejectedInactive, rejectedQuality, rejectedShape });
        } catch (e) {
          this.log.warn("Provider", `Provider hiba: ${p.id}`, { error: e.message });
        }
      }
      return out;
    }
  }