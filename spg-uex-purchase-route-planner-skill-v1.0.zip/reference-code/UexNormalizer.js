class UexNormalizer {
    commodity(r) {
      return {
        id: num(r.id),
        uuid: r.uuid || null,
        name: text(r.name).trim(),
        code: text(r.code || r.name).trim(),
        slug: r.slug || null,
        kind: r.kind || null,
        isLive: bool(r.is_available_live),
        isAvailable: bool(r.is_available),
        isVisible: r.is_visible == null ? true : bool(r.is_visible),
        isBuyable: bool(r.is_buyable),
        isRefined: bool(r.is_refined),
        isRaw: bool(r.is_raw),
        rawFlagKnown: r.is_raw !== null && r.is_raw !== undefined,
        refinedFlagKnown: r.is_refined !== null && r.is_refined !== undefined,
        isMineral: bool(r.is_mineral),
        isHarvestable: bool(r.is_harvestable),
        isFuel: bool(r.is_fuel),
        isIllegal: bool(r.is_illegal),
        modified: r.date_modified || null,
        isFallback: false,
      };
    }
    commodityFromPrice(p) {
      const name = text(p.commodityName || `Commodity ${p.commodityId}`).trim(),
        code = text(p.commodityCode || name).trim(),
        slug = text(p.commoditySlug || "").trim() || null,
        key = lower(`${name} ${code}`);
      return {
        id: p.commodityId,
        uuid: null,
        name,
        code,
        slug,
        kind: null,
        isLive: true,
        isAvailable: true,
        isVisible: true,
        isBuyable: true,
        isRefined: false,
        isRaw: false,
        rawFlagKnown: false,
        refinedFlagKnown: false,
        isMineral: false,
        isHarvestable: false,
        isFuel: /quantum fuel|hydrogen fuel|\bqfue\b|\bhydf\b/.test(key),
        isIllegal: false,
        modified: p.modified || null,
        isFallback: true,
      };
    }
    terminal(r) {
      const station = text(r.space_station_name).trim(),
        planet = text(r.planet_name).trim(),
        moon = text(r.moon_name).trim(),
        outpost = text(r.outpost_name).trim(),
        city = text(r.city_name).trim(),
        poi = text(r.poi_name).trim(),
        place = text(
          station ||
            outpost ||
            city ||
            poi ||
            r.fullname ||
            r.nickname ||
            r.name,
        ).trim(),
        body = text(moon || planet || r.orbit_name).trim(),
        locationType = station
          ? "station"
          : moon
            ? "moon"
            : planet
              ? "planet"
              : "other";
      return {
        id: num(r.id),
        name: text(r.displayname || r.name).trim(),
        canonical: text(r.fullname || r.name).trim(),
        type: r.type || null,
        system: text(r.star_system_name).trim(),
        body,
        place: place || text(r.name).trim(),
        planet,
        moon,
        station,
        outpost,
        city,
        poi,
        locationType,
        isLive: r.is_available_live == null ? true : bool(r.is_available_live),
        isVisible: r.is_visible == null ? true : bool(r.is_visible),
        freight: bool(r.has_freight_elevator),
        dock: bool(r.has_loading_dock),
        docking: bool(r.has_docking_port),
        autoLoad: bool(r.is_auto_load),
        maxContainer: num(r.max_container_size),
        gameVersion: r.game_version || null,
        modified: r.date_modified || null,
      };
    }
    price(r) {
      return {
        id: num(r.id),
        commodityId: num(r.id_commodity),
        terminalId: num(r.id_terminal),
        price: num(r.price_buy),
        priceAvg: num(r.price_buy_avg),
        stock: num(r.scu_buy),
        stockAvg: num(r.scu_buy_avg),
        reportedSellStock: num(r.scu_sell_stock),
        reportedSellStockAvg: num(r.scu_sell_stock_avg),
        status: num(r.status_buy),
        statusAvg: num(r.status_buy_avg),
        containers: parseCsvNumbers(r.container_sizes),
        quality: num(r.quality),
        modified: r.date_modified || r.date_added || null,
        gameVersion: r.game_version || null,
        commodityName: r.commodity_name || null,
        commodityCode: r.commodity_code || null,
        commoditySlug: r.commodity_slug || null,
        terminalName: r.terminal_name || null,
        terminalCode: r.terminal_code || null,
        starSystem: text(r.star_system_name).trim(),
        planet: text(r.planet_name).trim(),
        orbit: text(r.orbit_name).trim(),
        moon: text(r.moon_name).trim(),
        station: text(r.space_station_name).trim(),
        outpost: text(r.outpost_name).trim(),
        city: text(r.city_name).trim(),
        poi: text(r.poi_name).trim(),
        terminalIsPlayerOwned: bool(r.terminal_is_player_owned),
      };
    }
    terminalFromPrice(p) {
      const place =
          p.station ||
          p.outpost ||
          p.city ||
          p.poi ||
          p.terminalName ||
          "Ismeretlen hely",
        body = p.moon || p.planet || p.orbit || "",
        locationType = p.station
          ? "station"
          : p.moon
            ? "moon"
            : p.planet
              ? "planet"
              : "other";
      return {
        id: p.terminalId,
        name: p.terminalName || `Terminál ${p.terminalId}`,
        canonical: p.terminalName || `Terminál ${p.terminalId}`,
        type: "commodity",
        system: p.starSystem || "Ismeretlen rendszer",
        body,
        place,
        planet: p.planet || "",
        moon: p.moon || "",
        station: p.station || "",
        outpost: p.outpost || "",
        city: p.city || "",
        poi: p.poi || "",
        locationType,
        isLive: true,
        isVisible: true,
        freight: false,
        dock: false,
        docking: false,
        autoLoad: false,
        maxContainer: p.containers.length ? Math.max(...p.containers) : null,
        gameVersion: p.gameVersion || null,
        modified: p.modified || null,
        isFallback: true,
      };
    }
    vehicle(r) {
      return {
        id: num(r.id),
        uuid: r.uuid || null,
        name: text(r.name_full || r.name).trim(),
        shortName: text(r.name).trim(),
        scu: num(r.scu) || 0,
        containers: parseCsvNumbers(r.container_sizes),
        isCargo: bool(r.is_cargo),
        isConcept: bool(r.is_concept),
        isGround: bool(r.is_ground_vehicle),
        isShip:
          r.is_spaceship == null
            ? !bool(r.is_ground_vehicle)
            : bool(r.is_spaceship),
        loadingDock: bool(r.is_loading_dock),
        pad: r.pad_type || null,
        manufacturer: r.company_name || null,
        gameVersion: r.game_version || null,
        modified: r.date_modified || null,
      };
    }
  }