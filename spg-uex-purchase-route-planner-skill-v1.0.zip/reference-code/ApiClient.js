class ApiClient {
    constructor(log, getSettings) {
      this.log = log;
      this.getSettings = getSettings;
      this.stats = {
        requests: 0,
        success: 0,
        failed: 0,
        retries: 0,
        lastBase: null,
      };
    }
    async get(resource) {
      const s = this.getSettings();
      const bases = unique([s.apiBase, ...CONFIG.apiFallbacks]);
      let last;
      for (const base of bases) {
        for (let attempt = 0; attempt < 2; attempt++) {
          this.stats.requests++;
          const c = new AbortController(),
            t = setTimeout(() => c.abort(), CONFIG.requestTimeoutMs);
          try {
            const headers = { Accept: "application/json" };
            if (s.token) headers.Authorization = `Bearer ${s.token}`;
            const r = await fetch(`${base.replace(/\/$/, "")}/${resource}`, {
              headers,
              mode: "cors",
              cache: "no-store",
              signal: c.signal,
            });
            clearTimeout(t);
            if (!r.ok)
              throw Object.assign(
                new Error(`HTTP ${r.status} ${r.statusText}`),
                { status: r.status },
              );
            const p = await r.json();
            if (p?.status && p.status !== "ok")
              throw new Error(p.message || p.status);
            this.stats.success++;
            this.stats.lastBase = base;
            return unwrap(p);
          } catch (e) {
            clearTimeout(t);
            last = e;
            if (
              attempt === 0 &&
              (e.name === "AbortError" || e.status >= 500 || e.status === 429)
            ) {
              this.stats.retries++;
              await sleep(500);
              continue;
            }
            break;
          }
        }
      }
      this.stats.failed++;
      throw last || new Error("UEX API nem érhető el.");
    }
  }