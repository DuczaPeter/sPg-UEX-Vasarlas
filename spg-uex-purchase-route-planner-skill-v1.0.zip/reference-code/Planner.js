class Planner {
    constructor(log) {
      this.log = log;
      this.packCache = new Map();
    }
    normalizeLocationPart(value) {
      return lower(value)
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/\b(space\s+station|station)\b$/g, "")
        .replace(/[^a-z0-9()]+/g, "-")
        .replace(/^-+|-+$/g, "");
    }
    locationKey(o) {
      if (o?.physicalLocationKey) return String(o.physicalLocationKey);
      const system = this.normalizeLocationPart(o?.system || "unknown-system");
      const place = this.normalizeLocationPart(
        o?.place || o?.station || o?.outpost || o?.city || o?.poi || "unknown-place",
      );
      return `${system}|${place}`;
    }
    isOutOfStock(o) {
      return Number(o.stockStatus) === 1;
    }
    hasExactStock(o) {
      return Number(o.stock) > 0;
    }
    isQuantityUnknown(o) {
      return !this.isOutOfStock(o) && !this.hasExactStock(o);
    }
    isUsable(o, allowUnknown) {
      return (
        Number(o.price) > 0 &&
        !this.isOutOfStock(o) &&
        o.containerCompatible !== false &&
        (this.hasExactStock(o) || allowUnknown)
      );
    }
    applyFilters(offers, f, ship) {
      return offers.filter((o) => {
        const locationType = f.locationType || "any";
        if (locationType === "planet" && o.locationType !== "planet") return false;
        if (locationType === "moon" && o.locationType !== "moon") return false;
        if (
          locationType === "surface" &&
          !["planet", "moon"].includes(o.locationType)
        )
          return false;
        if (locationType === "station" && o.locationType !== "station") return false;
        if (f.system && o.system !== f.system) return false;
        if (f.body && o.body !== f.body) return false;
        if (f.place && o.place !== f.place) return false;
        const mode =
          f.loadMode === "auto"
            ? ship?.loadingDock
              ? "dock"
              : "any"
            : f.loadMode;
        if (mode === "freight" && !o.freight) return false;
        if (mode === "dock" && !o.dock) return false;
        if (mode === "either" && !o.freight && !o.dock) return false;
        if (
          f.minContainer &&
          !(o.compatibleContainers || []).some((n) => n >= f.minContainer)
        )
          return false;
        return true;
      });
    }
    sortOffers(rows) {
      return rows.sort(
        (a, b) =>
          Number(a.price || 0) - Number(b.price || 0) ||
          Number(this.isQuantityUnknown(a)) - Number(this.isQuantityUnknown(b)) ||
          (b.modifiedMs || 0) - (a.modifiedMs || 0) ||
          this.locationKey(a).localeCompare(this.locationKey(b)) ||
          String(a.terminalId || "").localeCompare(String(b.terminalId || "")),
      );
    }
    containerScale(sizes) {
      return sizes.some((n) => Math.abs(n - Math.round(n)) > 1e-9) ? 100 : 1;
    }
    buildReachability(limit, coins) {
      const prev = new Int32Array(limit + 1);
      prev.fill(-1);
      prev[0] = -2;
      for (let i = 1; i <= limit; i++) {
        for (const coin of coins) {
          if (i >= coin && prev[i - coin] !== -1) {
            prev[i] = coin;
            break;
          }
        }
      }
      return prev;
    }
    reconstructCombination(total, prev, sizesByUnit, scale) {
      const counts = new Map();
      let cursor = total;
      while (cursor > 0) {
        const coin = prev[cursor];
        if (!(coin > 0)) return [];
        counts.set(coin, (counts.get(coin) || 0) + 1);
        cursor -= coin;
      }
      return [...counts.entries()]
        .map(([unit, count]) => ({
          size: sizesByUnit.get(unit) ?? unit / scale,
          count,
        }))
        .sort((a, b) => b.size - a.size);
    }
    packQuantity(target, sizes, stock, stockUnknown = false) {
      const cleanSizes = unique((sizes || []).map(Number).filter((n) => n > 0)).sort(
        (a, b) => a - b,
      );
      const exactStock = Number(stock) > 0 ? Number(stock) : null;
      const cacheKey = `${Number(target).toFixed(4)}|${cleanSizes.join(",")}|${exactStock ?? "unknown"}`;
      if (this.packCache.has(cacheKey)) return clone(this.packCache.get(cacheKey));
      if (!(target > 0)) return null;
      if (!cleanSizes.length) {
        const purchased = exactStock == null ? target : Math.min(target, exactStock);
        if (!(purchased > 0)) return null;
        const result = {
          purchasedQuantity: purchased,
          coveredQuantity: Math.min(target, purchased),
          overbuyQuantity: Math.max(0, purchased - target),
          containerCombination: [],
          containerKnown: false,
          exactCoverage: purchased + 1e-9 >= target,
        };
        this.packCache.set(cacheKey, result);
        return clone(result);
      }
      const scale = this.containerScale(cleanSizes);
      const coins = cleanSizes.map((n) => Math.round(n * scale));
      const sizesByUnit = new Map(coins.map((u, i) => [u, cleanSizes[i]]));
      const lower = Math.ceil(target * scale - 1e-9);
      const maxCoin = Math.max(...coins);
      const stockUnits = exactStock == null ? null : Math.floor(exactStock * scale + 1e-9);
      let limit;
      if (stockUnits != null && stockUnits < lower) limit = stockUnits;
      else {
        const searchWindow = Math.max(maxCoin * maxCoin, maxCoin * 8, 128 * scale);
        limit = lower + searchWindow;
        if (stockUnits != null) limit = Math.min(limit, stockUnits);
      }
      if (!(limit > 0)) return null;
      const prev = this.buildReachability(limit, coins);
      let chosen = -1;
      for (let i = lower; i <= limit; i++) {
        if (prev[i] !== -1) {
          chosen = i;
          break;
        }
      }
      if (chosen < 0) {
        for (let i = Math.min(limit, lower - 1); i > 0; i--) {
          if (prev[i] !== -1) {
            chosen = i;
            break;
          }
        }
      }
      if (chosen < 0) return null;
      const purchasedQuantity = chosen / scale;
      const coveredQuantity = Math.min(target, purchasedQuantity);
      const result = {
        purchasedQuantity,
        coveredQuantity,
        overbuyQuantity: Math.max(0, purchasedQuantity - target),
        containerCombination: this.reconstructCombination(
          chosen,
          prev,
          sizesByUnit,
          scale,
        ),
        containerKnown: true,
        exactCoverage: purchasedQuantity + 1e-9 >= target,
      };
      this.packCache.set(cacheKey, result);
      return clone(result);
    }
    offerAllocation(o, remaining, requested, allowUnknown) {
      if (!this.isUsable(o, allowUnknown)) return null;
      const stockUnknown = this.isQuantityUnknown(o);
      const pack = this.packQuantity(
        remaining,
        o.compatibleContainers || [],
        stockUnknown ? null : Number(o.stock),
        stockUnknown,
      );
      if (!pack || !(pack.coveredQuantity > 0)) return null;
      return {
        ...o,
        requested,
        quantity: pack.purchasedQuantity,
        purchasedQuantity: pack.purchasedQuantity,
        coveredQuantity: pack.coveredQuantity,
        overbuyQuantity: pack.overbuyQuantity,
        cost: pack.purchasedQuantity * Number(o.price),
        stockUnknown,
        stockConfirmed: !stockUnknown,
        containerKnown: pack.containerKnown,
        containerCombination: pack.containerCombination,
      };
    }
    exactQuantityScale(requirement, offers) {
      const values = [
        Number(requirement?.quantity || 0),
        ...offers.flatMap((o) => [
          Number(o.stock || 0),
          ...(o.compatibleContainers || []).map(Number),
        ]),
      ].filter((n) => Number.isFinite(n));
      return values.some((n) => Math.abs(n - Math.round(n)) > 1e-9) ? 100 : 1;
    }
    exactStateBetter(candidate, current) {
      if (!current) return true;
      const costDiff = Number(candidate.cost || 0) - Number(current.cost || 0);
      if (Math.abs(costDiff) > 1e-6) return costDiff < 0;
      if (candidate.locationKeys.size !== current.locationKeys.size)
        return candidate.locationKeys.size < current.locationKeys.size;
      if (candidate.choices.length !== current.choices.length)
        return candidate.choices.length < current.choices.length;
      if (candidate.unknownStock !== current.unknownStock)
        return candidate.unknownStock < current.unknownStock;
      if (candidate.oldestModifiedMs !== current.oldestModifiedMs)
        return candidate.oldestModifiedMs > current.oldestModifiedMs;
      return candidate.signature.localeCompare(current.signature) < 0;
    }
    exactOfferOptions(offer, scale, capUnits) {
      const stockUnknown = this.isQuantityUnknown(offer);
      const exactStockUnits = stockUnknown
        ? capUnits
        : Math.max(0, Math.floor(Number(offer.stock || 0) * scale + 1e-9));
      const limit = Math.min(capUnits, exactStockUnits);
      if (!(limit > 0)) return [];
      const sizes = unique((offer.compatibleContainers || []).map(Number).filter((n) => n > 0)).sort(
        (a, b) => a - b,
      );
      if (!sizes.length) {
        const options = [];
        for (let units = 1; units <= limit; units++)
          options.push({ units, containerCombination: [], containerKnown: false });
        return options;
      }
      const coins = sizes.map((n) => Math.round(n * scale)).filter((n) => n > 0);
      const sizesByUnit = new Map(coins.map((u, i) => [u, sizes[i]]));
      const prev = this.buildReachability(limit, coins);
      const options = [];
      for (let units = 1; units <= limit; units++) {
        if (prev[units] === -1) continue;
        options.push({
          units,
          containerCombination: this.reconstructCombination(units, prev, sizesByUnit, scale),
          containerKnown: true,
        });
      }
      return options;
    }
    exactOfferUnitData(offer, scale, capUnits) {
      const stockUnknown = this.isQuantityUnknown(offer);
      const exactStockUnits = stockUnknown
        ? capUnits
        : Math.max(0, Math.floor(Number(offer.stock || 0) * scale + 1e-9));
      const limit = Math.min(capUnits, exactStockUnits);
      if (!(limit > 0))
        return {
          units: [],
          containerKnown: false,
          reachability: null,
          sizesByUnit: null,
        };
      const sizes = unique(
        (offer.compatibleContainers || []).map(Number).filter((n) => n > 0),
      ).sort((a, b) => a - b);
      if (!sizes.length) {
        const units = new Int32Array(limit);
        for (let i = 0; i < limit; i++) units[i] = i + 1;
        return {
          units,
          containerKnown: false,
          reachability: null,
          sizesByUnit: null,
        };
      }
      const coins = sizes
        .map((n) => Math.round(n * scale))
        .filter((n) => n > 0);
      const sizesByUnit = new Map(coins.map((u, i) => [u, sizes[i]]));
      const reachability = this.buildReachability(limit, coins);
      const values = [];
      for (let units = 1; units <= limit; units++)
        if (reachability[units] !== -1) values.push(units);
      return {
        units: Int32Array.from(values),
        containerKnown: true,
        reachability,
        sizesByUnit,
      };
    }
    exactCommodityPlan(requirement, offers, allowUnknown, ship = null) {
      const startedAt = performance.now();
      const rows = offers
        .filter(
          (o) =>
            Number(o.commodityId) === Number(requirement.commodityId) &&
            this.isUsable(o, allowUnknown),
        )
        .sort(
          (a, b) =>
            Number(a.price || 0) - Number(b.price || 0) ||
            this.locationKey(a).localeCompare(this.locationKey(b)) ||
            String(a.terminalId || '').localeCompare(String(b.terminalId || '')),
        );
      if (!rows.length) {
        const plan = this.finish(
          [],
          [{ ...requirement, missing: Number(requirement.quantity || 0) }],
          'exact-cost-empty',
          [requirement],
          ship,
        );
        return {
          supported: true,
          plan,
          audit: {
            commodityId: Number(requirement.commodityId),
            commodityName: requirement.commodityName || requirement.name || null,
            offers: 0,
            scale: 1,
            targetUnits: Math.ceil(Number(requirement.quantity || 0)),
            capUnits: Math.ceil(Number(requirement.quantity || 0)),
            statesEvaluated: 1,
            transitionsEvaluated: 0,
            durationMs: Math.round((performance.now() - startedAt) * 10) / 10,
            engine: 'typed-array-dp-v2',
            complete: false,
            exactCost: 0,
            coveredQuantity: 0,
            purchasedQuantity: 0,
            missingQuantity: Number(requirement.quantity || 0),
          },
        };
      }
      const scale = this.exactQuantityScale(requirement, rows);
      const targetUnits = Math.max(
        1,
        Math.ceil(Number(requirement.quantity || 0) * scale - 1e-9),
      );
      const maxContainerUnits = Math.max(
        scale,
        ...rows
          .flatMap((o) =>
            (o.compatibleContainers || []).map((n) =>
              Math.round(Number(n) * scale),
            ),
          )
          .filter((n) => n > 0),
      );
      const capUnits = targetUnits + Math.max(0, maxContainerUnits - 1);
      const hardCapUnits = 4096;
      const estimatedTransitions =
        rows.length * capUnits * Math.max(1, Math.min(capUnits, 128));
      if (capUnits > hardCapUnits || estimatedTransitions > 60000000) {
        return {
          supported: false,
          reason:
            capUnits > hardCapUnits
              ? 'quantity-grid-too-large'
              : 'transition-budget-exceeded',
          audit: {
            commodityId: Number(requirement.commodityId),
            commodityName: requirement.commodityName || requirement.name || null,
            offers: rows.length,
            scale,
            targetUnits,
            capUnits,
            hardCapUnits,
            estimatedTransitions,
            durationMs: Math.round((performance.now() - startedAt) * 10) / 10,
            engine: 'typed-array-dp-v2',
          },
        };
      }

      const offerData = rows.map((offer) => ({
        offer,
        ...this.exactOfferUnitData(offer, scale, capUnits),
      }));
      const INF = Number.POSITIVE_INFINITY;
      const MAX_INT = 0x3fffffff;
      let previousCost = new Float64Array(capUnits + 1);
      previousCost.fill(INF);
      previousCost[0] = 0;
      let previousChoices = new Int32Array(capUnits + 1);
      previousChoices.fill(MAX_INT);
      previousChoices[0] = 0;
      let previousUnknown = new Int32Array(capUnits + 1);
      previousUnknown.fill(MAX_INT);
      previousUnknown[0] = 0;
      const parents = [];
      let statesEvaluated = 1;
      let transitionsEvaluated = 0;

      for (const data of offerData) {
        const nextCost = previousCost.slice();
        const nextChoices = previousChoices.slice();
        const nextUnknown = previousUnknown.slice();
        const parentUnits = new Int32Array(capUnits + 1);
        parentUnits.fill(-1);
        const chosenUnits = new Int32Array(capUnits + 1);
        for (let units = 0; units <= capUnits; units++)
          if (Number.isFinite(previousCost[units])) parentUnits[units] = units;

        const pricePerUnit = Number(data.offer.price || 0) / scale;
        const unknownIncrement = Number(this.isQuantityUnknown(data.offer));
        for (let baseUnits = 0; baseUnits <= capUnits; baseUnits++) {
          const baseCost = previousCost[baseUnits];
          if (!Number.isFinite(baseCost)) continue;
          const maxOption = capUnits - baseUnits;
          for (let oi = 0; oi < data.units.length; oi++) {
            const optionUnits = data.units[oi];
            if (optionUnits > maxOption) break;
            transitionsEvaluated++;
            const totalUnits = baseUnits + optionUnits;
            const candidateCost = baseCost + optionUnits * pricePerUnit;
            const candidateChoices = previousChoices[baseUnits] + 1;
            const candidateUnknown =
              previousUnknown[baseUnits] + unknownIncrement;
            const costDiff = candidateCost - nextCost[totalUnits];
            const better =
              costDiff < -1e-6 ||
              (Math.abs(costDiff) <= 1e-6 &&
                (candidateChoices < nextChoices[totalUnits] ||
                  (candidateChoices === nextChoices[totalUnits] &&
                    candidateUnknown < nextUnknown[totalUnits])));
            if (!better) continue;
            nextCost[totalUnits] = candidateCost;
            nextChoices[totalUnits] = candidateChoices;
            nextUnknown[totalUnits] = candidateUnknown;
            parentUnits[totalUnits] = baseUnits;
            chosenUnits[totalUnits] = optionUnits;
          }
        }
        let layerStates = 0;
        for (let units = 0; units <= capUnits; units++)
          if (Number.isFinite(nextCost[units])) layerStates++;
        statesEvaluated += layerStates;
        parents.push({ parentUnits, chosenUnits, data });
        previousCost = nextCost;
        previousChoices = nextChoices;
        previousUnknown = nextUnknown;
      }

      let bestUnits = -1;
      for (let units = targetUnits; units <= capUnits; units++) {
        if (!Number.isFinite(previousCost[units])) continue;
        if (bestUnits < 0) {
          bestUnits = units;
          continue;
        }
        const costDiff = previousCost[units] - previousCost[bestUnits];
        if (
          costDiff < -1e-6 ||
          (Math.abs(costDiff) <= 1e-6 &&
            (previousChoices[units] < previousChoices[bestUnits] ||
              (previousChoices[units] === previousChoices[bestUnits] &&
                (units < bestUnits ||
                  (units === bestUnits &&
                    previousUnknown[units] < previousUnknown[bestUnits])))))
        )
          bestUnits = units;
      }
      if (bestUnits < 0) {
        for (let units = capUnits; units >= 0; units--)
          if (Number.isFinite(previousCost[units])) {
            bestUnits = units;
            break;
          }
      }

      const selectedChoices = [];
      let cursor = Math.max(0, bestUnits);
      for (let index = parents.length - 1; index >= 0; index--) {
        const layer = parents[index];
        const optionUnits = layer.chosenUnits[cursor];
        const priorUnits = layer.parentUnits[cursor];
        if (priorUnits < 0)
          throw new Error('Az exact DP visszafejtése érvénytelen állapotba került.');
        if (optionUnits > 0) {
          const combination = layer.data.containerKnown
            ? this.reconstructCombination(
                optionUnits,
                layer.data.reachability,
                layer.data.sizesByUnit,
                scale,
              )
            : [];
          selectedChoices.push({
            offer: layer.data.offer,
            units: optionUnits,
            containerCombination: combination,
            containerKnown: layer.data.containerKnown,
          });
        }
        cursor = priorUnits;
      }
      selectedChoices.reverse();
      selectedChoices.sort(
        (a, b) =>
          Number(a.offer.price || 0) - Number(b.offer.price || 0) ||
          this.locationKey(a.offer).localeCompare(this.locationKey(b.offer)) ||
          String(a.offer.terminalId || '').localeCompare(
            String(b.offer.terminalId || ''),
          ),
      );

      let remaining = Number(requirement.quantity || 0);
      const allocations = selectedChoices.map((choice) => {
        const purchasedQuantity = choice.units / scale;
        const coveredQuantity = Math.min(remaining, purchasedQuantity);
        remaining = Math.max(0, remaining - coveredQuantity);
        return {
          ...choice.offer,
          requested: Number(requirement.quantity || 0),
          quantity: purchasedQuantity,
          purchasedQuantity,
          coveredQuantity,
          overbuyQuantity: Math.max(0, purchasedQuantity - coveredQuantity),
          cost: purchasedQuantity * Number(choice.offer.price || 0),
          stockUnknown: this.isQuantityUnknown(choice.offer),
          stockConfirmed: !this.isQuantityUnknown(choice.offer),
          containerKnown: choice.containerKnown,
          containerCombination: choice.containerCombination,
        };
      });
      const missing =
        remaining > 1e-6 ? [{ ...requirement, missing: remaining }] : [];
      const plan = this.finish(
        allocations,
        missing,
        'exact-commodity-cost',
        [requirement],
        ship,
      );
      return {
        supported: true,
        plan,
        audit: {
          commodityId: Number(requirement.commodityId),
          commodityName: requirement.commodityName || requirement.name || null,
          offers: rows.length,
          scale,
          targetUnits,
          capUnits,
          statesEvaluated,
          transitionsEvaluated,
          durationMs: Math.round((performance.now() - startedAt) * 10) / 10,
          engine: 'typed-array-dp-v2',
          complete: plan.complete,
          exactCost: plan.totalCost,
          coveredQuantity: plan.coveredQty,
          purchasedQuantity: plan.totalQty,
          missingQuantity: this.missingTotal(plan),
          stops: plan.stops,
          transactions: plan.transactions,
        },
      };
    }
    exactBasketCostPlan(requirements, offers, allowUnknown, ship = null) {
      const startedAt = performance.now();
      const parts = [];
      const audits = [];
      for (const requirement of requirements) {
        const result = this.exactCommodityPlan(requirement, offers, allowUnknown, ship);
        audits.push(result.audit || { commodityId: Number(requirement.commodityId), supported: false });
        if (!result.supported)
          return {
            supported: false,
            reason: result.reason || 'unsupported-commodity-grid',
            audits,
          };
        parts.push(result.plan);
      }
      const allocations = parts.flatMap((p) => p.allocations || []);
      const missing = parts.flatMap((p) => p.missing || []);
      const plan = this.finish(allocations, missing, 'exact-basket-cost', requirements, ship);
      return {
        supported: true,
        plan,
        audits,
        durationMs: Math.round((performance.now() - startedAt) * 10) / 10,
        engine: 'typed-array-dp-v2',
        proof: {
          method: 'independent-commodity-dynamic-programming',
          explanation:
            'A teljes vételár az anyagok költségeinek összege. Minden anyaghoz külön, konténer- és készlethelyes dinamikus program kereste meg a legkisebb költséget; ezek összege ezért a teljes kosár bizonyított legkisebb ára az aktuális adatmodellben.',
        },
      };
    }
    offerCoverageScores(requirements, offers, allowUnknown) {
      const reqIds = new Set(requirements.map((r) => Number(r.commodityId)));
      const map = new Map();
      for (const o of offers) {
        if (!reqIds.has(Number(o.commodityId)) || !this.isUsable(o, allowUnknown)) continue;
        const key = this.locationKey(o);
        if (!map.has(key)) map.set(key, new Set());
        map.get(key).add(Number(o.commodityId));
      }
      return new Map([...map.entries()].map(([k, v]) => [k, v.size]));
    }
    allocationForRequirements(
      requirements,
      offers,
      allowUnknown,
      { preferredLocations = [], mode = "optimized", ship = null } = {},
    ) {
      const allocations = [];
      const missing = [];
      const usedLocations = new Set(preferredLocations);
      const coverageScores = this.offerCoverageScores(requirements, offers, allowUnknown);
      const reqOrder = [...requirements].sort((a, b) => {
        const ca = offers.filter(
          (o) => o.commodityId === a.commodityId && this.isUsable(o, allowUnknown),
        ).length;
        const cb = offers.filter(
          (o) => o.commodityId === b.commodityId && this.isUsable(o, allowUnknown),
        ).length;
        return ca - cb || Number(b.quantity) - Number(a.quantity);
      });
      for (const req of reqOrder) {
        let remain = Number(req.quantity);
        const rejected = new Set();
        while (remain > 1e-6) {
          const options = offers
            .filter(
              (o) =>
                o.commodityId === req.commodityId &&
                this.isUsable(o, allowUnknown) &&
                !rejected.has(String(o.terminalId)),
            )
            .map((o) => {
              const alloc = this.offerAllocation(
                o,
                remain,
                Number(req.quantity),
                allowUnknown,
              );
              if (!alloc) return null;
              const loc = this.locationKey(o);
              return {
                o,
                alloc,
                loc,
                alreadyUsed: usedLocations.has(loc) ? 1 : 0,
                coverageScore: coverageScores.get(loc) || 0,
                effectiveCost: alloc.cost / Math.max(alloc.coveredQuantity, 1e-9),
              };
            })
            .filter(Boolean)
            .sort(
              (a, b) =>
                a.effectiveCost - b.effectiveCost ||
                a.alloc.cost - b.alloc.cost ||
                b.alreadyUsed - a.alreadyUsed ||
                b.coverageScore - a.coverageScore ||
                Number(a.alloc.stockUnknown) - Number(b.alloc.stockUnknown) ||
                (b.alloc.modifiedMs || 0) - (a.alloc.modifiedMs || 0) ||
                a.loc.localeCompare(b.loc) ||
                String(a.o.terminalId).localeCompare(String(b.o.terminalId)),
            );
          const best = options[0];
          if (!best) break;
          allocations.push(best.alloc);
          usedLocations.add(best.loc);
          remain -= best.alloc.coveredQuantity;
          rejected.add(String(best.o.terminalId));
        }
        if (remain > 1e-6) missing.push({ ...req, missing: remain });
      }
      return this.finish(allocations, missing, mode, requirements, ship);
    }
    cheapest(requirements, offers, allowUnknown, ship = null) {
      return this.allocationForRequirements(requirements, offers, allowUnknown, {
        mode: "cheapest",
        ship,
      });
    }
    practical(requirements, offers, allowUnknown, ship = null) {
      const locations = this.singleLocations(requirements, offers, allowUnknown, ship);
      const completeSingle = locations.filter((p) => p.complete);
      if (completeSingle.length)
        return completeSingle
          .map((p) => p.plan)
          .sort((a, b) => this.compareMainPlans(a, b, ship))[0];
      const pool = this.locationCandidatePool(requirements, offers, allowUnknown);
      const topKeys = pool.slice(0, Math.min(8, pool.length)).map((x) => x.key);
      const subsetOffers = offers.filter((o) => topKeys.includes(this.locationKey(o)));
      return this.allocationForRequirements(requirements, subsetOffers, allowUnknown, {
        mode: "practical",
        ship,
      });
    }
    finish(alloc, missing, mode, requirements = [], ship = null) {
      const groups = new Map();
      for (const a of alloc) {
        const key = this.locationKey(a);
        if (!groups.has(key))
          groups.set(key, {
            key,
            system: a.system,
            body: a.body,
            place: a.place,
            locationType: a.locationType || "other",
            lines: [],
            cost: 0,
            quantity: 0,
            coveredQuantity: 0,
            overbuyQuantity: 0,
            terminalIds: new Set(),
            freight: false,
            dock: false,
          });
        const g = groups.get(key);
        g.lines.push(a);
        g.cost += a.cost;
        g.quantity += Number(a.purchasedQuantity ?? a.quantity ?? 0);
        g.coveredQuantity += Number(a.coveredQuantity ?? a.quantity ?? 0);
        g.overbuyQuantity += Number(a.overbuyQuantity || 0);
        g.terminalIds.add(a.terminalId);
        g.freight ||= a.freight;
        g.dock ||= a.dock;
      }
      const places = [...groups.values()]
        .map((g) => ({
          ...g,
          terminalIds: [...g.terminalIds],
          types: new Set(g.lines.map((l) => l.commodityId)).size,
        }))
        .sort(
          (a, b) =>
            a.cost - b.cost || b.types - a.types || a.key.localeCompare(b.key),
        );
      const totalCost = alloc.reduce((sum, a) => sum + Number(a.cost || 0), 0);
      const totalQty = alloc.reduce(
        (sum, a) => sum + Number(a.purchasedQuantity ?? a.quantity ?? 0),
        0,
      );
      const coveredQty = alloc.reduce(
        (sum, a) => sum + Number(a.coveredQuantity ?? a.quantity ?? 0),
        0,
      );
      const requestedQty = requirements.reduce(
        (sum, r) => sum + Number(r.quantity || 0),
        0,
      );
      const overbuyQty = alloc.reduce(
        (sum, a) => sum + Number(a.overbuyQuantity || 0),
        0,
      );
      const transactionKeys = new Set(
        alloc.map((a) => `${a.providerId || "source"}|${a.terminalId}`),
      );
      const modifiedRows = alloc.map((a) => Number(a.modifiedMs || 0)).filter((v) => v > 0);
      const turns =
        ship && Number(ship.scu) > 0 && totalQty > 0
          ? Math.max(1, Math.ceil(totalQty / Number(ship.scu)))
          : null;
      const signature = alloc
        .map(
          (a) =>
            `${this.locationKey(a)}|${a.commodityId}|${a.terminalId}|${Number(
              a.purchasedQuantity ?? a.quantity ?? 0,
            ).toFixed(4)}`,
        )
        .sort()
        .join(";");
      return {
        mode,
        places,
        allocations: alloc,
        missing,
        totalCost,
        totalQty,
        purchasedQty: totalQty,
        coveredQty,
        requestedQty,
        overbuyQty,
        types: new Set(alloc.map((a) => a.commodityId)).size,
        stops: places.length,
        transactions: transactionKeys.size,
        unknownStock: alloc.filter((a) => a.stockUnknown).length,
        confirmedStock: alloc.filter((a) => a.stockConfirmed).length,
        containerUnknown: alloc.filter((a) => !a.containerKnown).length,
        complete: missing.length === 0,
        turns,
        oldestModifiedMs: modifiedRows.length ? Math.min(...modifiedRows) : 0,
        newestModifiedMs: modifiedRows.length ? Math.max(...modifiedRows) : 0,
        signature,
      };
    }
    missingTotal(plan) {
      return (plan?.missing || []).reduce((sum, r) => sum + Number(r.missing || 0), 0);
    }
    missingProfile(plan) {
      return (plan?.missing || [])
        .map((r) => `${Number(r.commodityId)}:${Number(r.missing || 0).toFixed(6)}:${r.unit || "SCU"}`)
        .sort()
        .join(";");
    }
    sameCompletionProfile(a, b) {
      if (Boolean(a?.complete) !== Boolean(b?.complete)) return false;
      return this.missingProfile(a) === this.missingProfile(b);
    }
    compareMainPlans(a, b, ship = null) {
      const ca = Number(Boolean(a?.complete));
      const cb = Number(Boolean(b?.complete));
      if (ca !== cb) return cb - ca;
      if (!a?.complete || !b?.complete) {
        const ma = this.missingTotal(a),
          mb = this.missingTotal(b);
        if (Math.abs(ma - mb) > 1e-6) return ma - mb;
        const mca = Number(a?.missing?.length || 0),
          mcb = Number(b?.missing?.length || 0);
        if (mca !== mcb) return mca - mcb;
      }
      const turnsA = a?.turns ?? (ship?.scu ? Math.ceil((a?.totalQty || 0) / ship.scu) : 0);
      const turnsB = b?.turns ?? (ship?.scu ? Math.ceil((b?.totalQty || 0) / ship.scu) : 0);
      return (
        Number(a?.totalCost || 0) - Number(b?.totalCost || 0) ||
        Number(a?.stops || 0) - Number(b?.stops || 0) ||
        Number(a?.transactions || 0) - Number(b?.transactions || 0) ||
        Number(turnsA || 0) - Number(turnsB || 0) ||
        Number(a?.unknownStock || 0) - Number(b?.unknownStock || 0) ||
        Number(a?.overbuyQty || 0) - Number(b?.overbuyQty || 0) ||
        Number(b?.oldestModifiedMs || 0) - Number(a?.oldestModifiedMs || 0) ||
        String(a?.signature || "").localeCompare(String(b?.signature || ""))
      );
    }
    compareFewestStopsPlans(a, b, ship = null) {
      const turnsA = a?.turns ?? (ship?.scu ? Math.ceil((a?.totalQty || 0) / ship.scu) : 0);
      const turnsB = b?.turns ?? (ship?.scu ? Math.ceil((b?.totalQty || 0) / ship.scu) : 0);
      return (
        Number(a?.stops || 0) - Number(b?.stops || 0) ||
        Number(a?.totalCost || 0) - Number(b?.totalCost || 0) ||
        Number(a?.transactions || 0) - Number(b?.transactions || 0) ||
        Number(turnsA || 0) - Number(turnsB || 0) ||
        Number(a?.unknownStock || 0) - Number(b?.unknownStock || 0) ||
        Number(a?.overbuyQty || 0) - Number(b?.overbuyQty || 0) ||
        String(a?.signature || "").localeCompare(String(b?.signature || ""))
      );
    }
    planFromSingleLocation(single, requirements, ship = null) {
      if (single?.plan) return single.plan;
      return this.finish(single.lines || [], [], "single", requirements, ship);
    }
    singleLocations(requirements, offers, allowUnknown = true, ship = null) {
      const groups = new Map();
      for (const o of offers) {
        const key = this.locationKey(o);
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key).push(o);
      }
      const out = [];
      for (const [key, rows] of groups) {
        const plan = this.allocationForRequirements(requirements, rows, allowUnknown, {
          mode: "single-location",
          ship,
          preferredLocations: [key],
        });
        if (!plan.allocations.length) continue;
        const g = plan.places[0] || {};
        out.push({
          key,
          system: g.system || rows[0]?.system,
          body: g.body || rows[0]?.body,
          place: g.place || rows[0]?.place,
          locationType: g.locationType || rows[0]?.locationType || "other",
          lines: plan.allocations,
          cost: plan.totalCost,
          quantity: plan.totalQty,
          coveredQuantity: plan.coveredQty,
          overbuyQuantity: plan.overbuyQty,
          types: plan.types,
          complete: plan.complete,
          freight: plan.places.some((p) => p.freight),
          dock: plan.places.some((p) => p.dock),
          plan,
        });
      }
      return out.sort((a, b) => this.compareMainPlans(a.plan, b.plan, ship));
    }
    locationCandidatePool(requirements, offers, allowUnknown) {
      const singles = this.singleLocations(requirements, offers, allowUnknown, null);
      return singles
        .map((s) => ({
          key: s.key,
          complete: s.complete,
          types: s.types,
          coverage: s.plan.requestedQty
            ? s.plan.coveredQty / s.plan.requestedQty
            : 0,
          cost: s.cost,
          unknown: s.plan.unknownStock,
        }))
        .sort(
          (a, b) =>
            Number(b.complete) - Number(a.complete) ||
            b.types - a.types ||
            b.coverage - a.coverage ||
            a.cost - b.cost ||
            a.key.localeCompare(b.key),
        );
    }
    subsetSearch(requirements, offers, allowUnknown, ship = null) {
      const reqIds = new Set(requirements.map((r) => Number(r.commodityId)));
      const relevantOffers = offers.filter(
        (o) => reqIds.has(Number(o.commodityId)) && this.isUsable(o, allowUnknown),
      );
      const grouped = new Map();
      for (const o of relevantOffers) {
        const key = this.locationKey(o);
        if (!grouped.has(key)) grouped.set(key, []);
        grouped.get(key).push(o);
      }
      const allKeys = [...grouped.keys()].sort();
      const exactLocationLimit = 14;
      const subsetPlans = [];
      const seenPlans = new Set();
      let evaluatedSubsets = 0;
      const evaluateKeys = (keys, mode) => {
        const subsetOffers = keys.flatMap((k) => grouped.get(k) || []);
        const plan = this.allocationForRequirements(requirements, subsetOffers, allowUnknown, {
          mode,
          ship,
          preferredLocations: keys,
        });
        evaluatedSubsets++;
        const planKey = `${plan.complete}|${this.missingProfile(plan)}|${plan.totalCost}|${plan.stops}|${plan.signature}`;
        if (plan.allocations.length && !seenPlans.has(planKey)) {
          seenPlans.add(planKey);
          subsetPlans.push(plan);
        }
        return plan;
      };

      if (allKeys.length <= exactLocationLimit) {
        const maxMask = 1 << allKeys.length;
        let maxStopsSearched = 0;
        for (let mask = 1; mask < maxMask; mask++) {
          const keys = [];
          for (let i = 0; i < allKeys.length; i++)
            if (mask & (1 << i)) keys.push(allKeys[i]);
          maxStopsSearched = Math.max(maxStopsSearched, keys.length);
          evaluateKeys(keys, `exact-subset-${keys.length}`);
        }
        return {
          plans: subsetPlans,
          stats: {
            optimality: "exact",
            searchMode: "exhaustive-location-subsets",
            optimalityReason:
              "Az összes releváns fizikai hely minden nem üres kombinációját ellenőrizte.",
            candidateLocationsTotal: allKeys.length,
            candidateLocationsSearched: allKeys.length,
            allCandidateLocationsConsidered: true,
            searchTruncated: false,
            evaluatedSubsets,
            completeSubsetPlans: subsetPlans.filter((p) => p.complete).length,
            partialSubsetPlans: subsetPlans.filter((p) => !p.complete).length,
            maxStopsSearched,
            beamWidth: null,
            exactLocationLimit,
          },
        };
      }

      const poolRanked = this.locationCandidatePool(requirements, relevantOffers, allowUnknown);
      const mustInclude = new Set();
      for (const req of requirements) {
        const rows = relevantOffers
          .filter((o) => o.commodityId === req.commodityId)
          .sort((a, b) =>
            Number(a.price) - Number(b.price) ||
            Number(b.stock || 0) - Number(a.stock || 0) ||
            this.locationKey(a).localeCompare(this.locationKey(b)),
          );
        rows.slice(0, 8).forEach((o) => mustInclude.add(this.locationKey(o)));
        const reqLocations = unique(rows.map((o) => this.locationKey(o)));
        if (reqLocations.length <= 3) reqLocations.forEach((k) => mustInclude.add(k));
      }
      const pool = unique([
        ...poolRanked.slice(0, 36).map((x) => x.key),
        ...mustInclude,
      ]).filter((k) => grouped.has(k));
      const beamWidth = 420;
      let beam = pool.map((key) => ({ keys: [key], key }));
      let maxStopsSearched = 0;
      for (let depth = 1; depth <= pool.length && beam.length; depth++) {
        maxStopsSearched = depth;
        const evaluated = [];
        for (const state of beam) {
          const plan = evaluateKeys(state.keys, `heuristic-subset-${depth}`);
          evaluated.push({
            ...state,
            plan,
            missingTotal: this.missingTotal(plan),
          });
        }
        if (depth >= pool.length) break;

        const completeStates = evaluated
          .filter((x) => x.plan.complete)
          .sort((a, b) => this.compareMainPlans(a.plan, b.plan, ship))
          .slice(0, Math.ceil(beamWidth / 2));
        const incompleteStates = evaluated
          .filter((x) => !x.plan.complete)
          .sort((a, b) => this.compareMainPlans(a.plan, b.plan, ship))
          .slice(0, Math.ceil(beamWidth / 2));
        const promising = [...completeStates, ...incompleteStates];
        const nextMap = new Map();
        for (const state of promising) {
          const lastIndex = Math.max(...state.keys.map((k) => pool.indexOf(k)));
          for (let i = lastIndex + 1; i < pool.length; i++) {
            const key = pool[i];
            if (state.keys.includes(key)) continue;
            const keys = [...state.keys, key];
            const comboKey = keys.join("||");
            if (!nextMap.has(comboKey)) nextMap.set(comboKey, { keys, key: comboKey });
          }
        }
        beam = [...nextMap.values()].slice(0, beamWidth * 2);
      }
      const allCandidateLocationsConsidered = pool.length === allKeys.length;
      return {
        plans: subsetPlans,
        stats: {
          optimality: "heuristic",
          searchMode: "adaptive-beam-all-depths",
          optimalityReason:
            "A releváns helyek száma túl nagy volt a teljes kombinációs bizonyításhoz; adaptív, több mélységű keresés futott.",
          candidateLocationsTotal: allKeys.length,
          candidateLocationsSearched: pool.length,
          allCandidateLocationsConsidered,
          searchTruncated: !allCandidateLocationsConsidered,
          evaluatedSubsets,
          completeSubsetPlans: subsetPlans.filter((p) => p.complete).length,
          partialSubsetPlans: subsetPlans.filter((p) => !p.complete).length,
          maxStopsSearched,
          beamWidth,
          exactLocationLimit,
        },
      };
    }
    tieBreakExplanation(main, equalCostPlans, ship = null) {
      const peers = equalCostPlans.filter((p) => p.signature !== main.signature);
      if (!peers.length) return [];
      const reasons = [];
      const all = [main, ...peers];
      const comparisonLabel = main.complete
        ? "Azonos teljes árnál"
        : "Azonos hiányzó mennyiség és azonos részösszeg mellett";
      const minStops = Math.min(...all.map((p) => Number(p.stops || 0)));
      if (main.stops === minStops && all.some((p) => p.stops > minStops)) {
        reasons.push(`${comparisonLabel} a ${main.stops} megállós terv nyert a több megállós változatokkal szemben.`);
        return reasons;
      }
      const sameStops = all.filter((p) => p.stops === main.stops);
      const minTransactions = Math.min(...sameStops.map((p) => Number(p.transactions || 0)));
      if (main.transactions === minTransactions && sameStops.some((p) => p.transactions > minTransactions)) {
        reasons.push(`Azonos ár és megállószám mellett a kevesebb, ${main.transactions} tranzakció döntött.`);
        return reasons;
      }
      const turnsOf = (p) =>
        p.turns ?? (ship?.scu ? Math.ceil((p.totalQty || 0) / ship.scu) : 0);
      const minTurns = Math.min(...sameStops.map(turnsOf));
      if (turnsOf(main) === minTurns && sameStops.some((p) => turnsOf(p) > minTurns)) {
        reasons.push(`Azonos ár, megálló és tranzakció mellett a kevesebb, ${minTurns} hajóforduló döntött.`);
        return reasons;
      }
      const minUnknown = Math.min(...sameStops.map((p) => Number(p.unknownStock || 0)));
      if (main.unknownStock === minUnknown && sameStops.some((p) => p.unknownStock > minUnknown)) {
        reasons.push("Azonos ár és útvonalhossz mellett a biztosabban jelentett készlet döntött.");
        return reasons;
      }
      const minOverbuy = Math.min(...sameStops.map((p) => Number(p.overbuyQty || 0)));
      if (Math.abs(main.overbuyQty - minOverbuy) < 1e-6 && sameStops.some((p) => p.overbuyQty > minOverbuy + 1e-6)) {
        reasons.push(`Azonos ár és megállószám mellett a kisebb, ${fmtQty(main.overbuyQty)} SCU túlvásárlás döntött.`);
        return reasons;
      }
      const maxFreshness = Math.max(...sameStops.map((p) => Number(p.oldestModifiedMs || 0)));
      if (main.oldestModifiedMs === maxFreshness && sameStops.some((p) => p.oldestModifiedMs < maxFreshness)) {
        reasons.push("Azonos ár és azonos útvonalterhelés mellett a frissebb legöregebb készletadat döntött.");
        return reasons;
      }
      reasons.push("Minden üzleti szempont azonos volt; a stabil hely- és terminálazonosító szerinti sorrend döntött, hogy ugyanaz az adat mindig ugyanazt az eredményt adja.");
      return reasons;
    }
    optimizeBasket(requirements, offers, allowUnknown, ship = null) {
      this.packCache.clear();
      const exactCost = this.exactBasketCostPlan(requirements, offers, allowUnknown, ship);
      const baseline = this.cheapest(requirements, offers, allowUnknown, ship);
      const singles = this.singleLocations(requirements, offers, allowUnknown, ship);
      const subset = this.subsetSearch(requirements, offers, allowUnknown, ship);
      const practical = this.practical(requirements, offers, allowUnknown, ship);
      const candidates = [
        exactCost.supported ? exactCost.plan : null,
        baseline,
        practical,
        ...singles.map((s) => s.plan),
        ...subset.plans,
      ].filter(Boolean);
      const uniquePlans = new Map();
      for (const p of candidates) {
        const key = `${p.complete}|${this.missingProfile(p)}|${p.totalCost}|${p.stops}|${p.signature}`;
        if (!uniquePlans.has(key)) uniquePlans.set(key, p);
      }
      const ranked = [...uniquePlans.values()].sort((a, b) =>
        this.compareMainPlans(a, b, ship),
      );
      let main;
      let exactCostMatches = null;
      if (exactCost.supported) {
        const exactProfile = this.missingProfile(exactCost.plan);
        const exactPrice = Number(exactCost.plan.totalCost || 0);
        const exactPeers = ranked.filter(
          (p) =>
            this.missingProfile(p) === exactProfile &&
            Math.abs(Number(p.totalCost || 0) - exactPrice) < 1e-6,
        );
        main = (exactPeers.length ? exactPeers : [exactCost.plan]).sort((a, b) =>
          this.compareMainPlans(a, b, ship),
        )[0];
        exactCostMatches = Math.abs(Number(main.totalCost || 0) - exactPrice) < 1e-6;
      } else main = ranked[0] || baseline;
      const sameCompletionPlans = ranked.filter(
        (p) => p.signature !== main.signature && this.sameCompletionProfile(p, main),
      );
      const fewerStops = sameCompletionPlans
        .filter((p) => p.stops < main.stops)
        .sort((a, b) => this.compareFewestStopsPlans(a, b, ship));
      const alternative = fewerStops[0] || null;
      const equalCostPlans = ranked.filter(
        (p) =>
          this.sameCompletionProfile(p, main) &&
          Math.abs(p.totalCost - main.totalCost) < 1e-6,
      );
      const rejectedEqualCostMoreStops = equalCostPlans.filter(
        (p) => p.signature !== main.signature && p.stops > main.stops,
      ).length;
      const tieBreakReasons = this.tieBreakExplanation(main, equalCostPlans, ship);
      const costOptimality = exactCost.supported && exactCostMatches ? 'exact' : 'heuristic';
      const routeOptimality = subset.stats.optimality === 'exact' ? 'candidate-exhaustive' : 'heuristic';
      const optimality = costOptimality === 'exact' ? 'cost-exact' : subset.stats.optimality;
      const reasonParts = [];
      if (main.complete) reasonParts.push('Az összes kért anyag teljes mennyisége beszerezhető.');
      else
        reasonParts.push(
          `A jelenlegi szűrőkkel ${main.missing.length} anyag maradt hiányos; a program az elérhető legnagyobb lefedettségű terveket hasonlította össze.`,
        );
      reasonParts.push('A program a teljes bevásárlólistát egyben hasonlította össze.');
      if (costOptimality === 'exact') {
        reasonParts.push(
          main.complete
            ? 'A legalacsonyabb teljes vételárat konténer- és készlethelyes dinamikus optimalizálás bizonyította.'
            : 'Az elérhető legnagyobb lefedettséghez tartozó legalacsonyabb részösszeget konténer- és készlethelyes dinamikus optimalizálás bizonyította.',
        );
        reasonParts.push(
          routeOptimality === 'candidate-exhaustive'
            ? 'Az azonos árú útvonalak közül az összes fizikai helyrészhalmaz vizsgálata alapján választotta a kevesebb megállós tervet.'
            : 'Az azonos árú útvonalak közül a vizsgált jelöltek alapján választotta a kevesebb megállós tervet; a vételár pontos, az útvonal-tie-break nagy keresési térben közelítő lehet.',
        );
      } else if (subset.stats.optimality === 'exact') {
        reasonParts.push(
          main.complete
            ? 'A releváns helyek minden kombinációját ellenőrizte; a keresési térben ez a legalacsonyabb tényleges költségű terv.'
            : 'A releváns helyek minden kombinációját ellenőrizte; azonos hiány mellett ez a legalacsonyabb részösszegű, majd a legkevesebb megállós részleges terv.',
        );
      } else {
        reasonParts.push(
          main.complete
            ? 'Adaptív, több mélységű keresésben ez lett a legalacsonyabb tényleges költségű talált terv. Az eredmény közelítő, nem matematikailag bizonyított optimum.'
            : 'Adaptív, több mélységű keresésben ez lett a legjobb talált részleges terv. Az eredmény közelítő, nem matematikailag bizonyított optimum.',
        );
      }
      reasonParts.push(...tieBreakReasons);
      if (rejectedEqualCostMoreStops)
        reasonParts.push(
          `${rejectedEqualCostMoreStops} azonos lefedettségű és azonos árú, de több megállós tervet elvetett.`,
        );
      if (main.overbuyQty > 1e-6)
        reasonParts.push(
          `A konténerméretek miatt ${fmtQty(main.overbuyQty)} SCU túlvásárlás szükséges.`,
        );
      const mainWithAudit = {
        ...main,
        optimality,
        costOptimality,
        routeOptimality,
        searchMode:
          costOptimality === 'exact'
            ? 'exact-commodity-cost-dp-plus-route-candidates'
            : subset.stats.searchMode,
        selectionReason: reasonParts,
      };
      return {
        main: mainWithAudit,
        alternative: alternative
          ? {
              ...alternative,
              optimality,
              costOptimality: 'not-primary-objective',
              routeOptimality,
              searchMode: subset.stats.searchMode,
              selectionReason: [
                main.complete
                  ? 'Ugyanazt a teljes bevásárlólistát kevesebb megállóval teljesíti.'
                  : 'Ugyanazt a részleges lefedettséget kevesebb megállóval adja.',
              ],
            }
          : null,
        singleLocations: singles,
        candidates: ranked,
        stats: {
          totalCandidates: ranked.length,
          completeCandidates: ranked.filter((p) => p.complete).length,
          partialCandidates: ranked.filter((p) => !p.complete).length,
          equalCostCandidates: equalCostPlans.length,
          equalCompletionCostCandidates: equalCostPlans.length,
          rejectedEqualCostMoreStops,
          tieBreakReasons,
          mainCompletionProfile: this.missingProfile(main),
          mainSignature: main.signature,
          alternativeSignature: alternative?.signature || null,
          exactCostSolver: {
            supported: exactCost.supported,
            reason: exactCost.reason || null,
            costMatchesMain: exactCostMatches,
            exactCost: exactCost.supported ? exactCost.plan.totalCost : null,
            exactMissingProfile: exactCost.supported
              ? this.missingProfile(exactCost.plan)
              : null,
            proof: exactCost.proof || null,
            commodities: exactCost.audits || [],
            durationMs: exactCost.durationMs ?? null,
            engine: exactCost.engine || null,
          },
          subsetSearch: subset.stats,
          ...subset.stats,
          optimality,
          costOptimality,
          routeOptimality,
        },
      };
    }

  }