// Exact method extracts from sPg UEX Vásárlás V1.0.36.
// These are App class methods, not a standalone module.
// Required dependencies include CONFIG, clone, num, lower, text, nowIso,
// currentRouteContext(), physical-location helpers, ApiClient, storage and logging.
// Preserve behavior; adapt only the surrounding state and I/O contract.

class DistanceRoutingReference {
// ===== terminalDistance =====
    async terminalDistance(a, b) {
      const origin = Number(a || 0), destination = Number(b || 0);
      if (!(origin > 0) || !(destination > 0)) return null;
      if (origin === destination) return 0;
      const cached = this.cachedTerminalDistanceEntry(origin, destination);
      if (cached?.state === "ok") {
        this.distanceStats.cacheHits++;
        return cached.distance;
      }
      if (cached?.state === "missing" || cached?.state === "error") {
        this.distanceStats.negativeCacheHits++;
        return null;
      }
      const key = this.distancePairKey(origin, destination);
      if (this.distanceInflight.has(key)) {
        this.distanceStats.inFlightHits++;
        return this.distanceInflight.get(key);
      }
      this.distanceStats.cacheMisses++;
      const task = (async () => {
        try {
          this.distanceStats.requests++;
          const payload = await this.api.get(`terminals_distances?id_terminal_origin=${encodeURIComponent(origin)}&id_terminal_destination=${encodeURIComponent(destination)}`),
            parsed = this.extractTerminalDistance(payload);
          if (parsed.distance == null) {
            this.distanceStats.noData++;
            this.rememberUnavailableTerminalDistance(origin, destination, "missing", parsed.reason, parsed);
            this.log.warn("Distance", "A UEX nem adott használható termináltávolságot; a pár ideiglenesen megjegyezve, a tartalék sorrend marad.", {
              origin,
              destination,
              reason: parsed.reason,
              response: parsed.summary,
              negativeCacheMinutes: Math.round(CONFIG.distanceNegativeTtlMs / 60000),
            });
            return null;
          }
          if (parsed.alternateField) this.distanceStats.alternateFieldParsed++;
          this.rememberTerminalDistance(origin, destination, parsed.distance, parsed);
          return parsed.distance;
        } catch (e) {
          this.distanceStats.failed++;
          this.rememberUnavailableTerminalDistance(origin, destination, "error", e.message, { summary: { type: "api-error", keys: [] } });
          this.log.warn("Distance", "Termináltávolság nem kérhető le; a hibás pár rövid ideig cache-elve, a tartalék sorrend marad.", {
            origin,
            destination,
            error: e.message,
            negativeCacheMinutes: Math.round(CONFIG.distanceErrorTtlMs / 60000),
          });
          return null;
        } finally {
          this.distanceInflight.delete(key);
        }
      })();
      this.distanceInflight.set(key, task);
      return task;
    }

// ===== terminalDistanceMatrix =====
    async terminalDistanceMatrix(nodes) {
      const valid = nodes.filter((n) => Number(n?.terminalId || 0) > 0),
        matrix = new Map(),
        pairs = [],
        seen = new Set();
      matrix.knownUnavailablePairs = 0;
      matrix.sameLocationZeroPairs = 0;
      for (let i = 0; i < valid.length; i++)
        for (let j = i + 1; j < valid.length; j++) {
          const a = Number(valid[i].terminalId),
            b = Number(valid[j].terminalId),
            key = this.distancePairKey(a, b);
          if (!key || seen.has(key)) continue;
          seen.add(key);
          if (a === b || this.samePhysicalLocation(valid[i], valid[j])) {
            matrix.set(key, 0);
            matrix.sameLocationZeroPairs++;
            this.distanceStats.sameLocationZeroPairs++;
            if (a !== b)
              this.rememberTerminalDistance(a, b, 0, {
                field: "same-physical-location",
              });
            continue;
          }
          pairs.push({ a, b, key });
        }
      const missingPairs = [];
      for (const pair of pairs) {
        const cached = this.cachedTerminalDistanceEntry(pair.a, pair.b);
        if (cached?.state === "ok") {
          matrix.set(pair.key, cached.distance);
          this.distanceStats.cacheHits++;
        } else if (cached?.state === "missing" || cached?.state === "error") {
          matrix.knownUnavailablePairs++;
          this.distanceStats.negativeCacheHits++;
        } else missingPairs.push(pair);
      }
      if (!Number.isFinite(this.distanceRequestBudgetRemaining))
        this.distanceRequestBudgetRemaining = CONFIG.distanceRequestBudgetPerCalculation;
      if (missingPairs.length > this.distanceRequestBudgetRemaining) {
        matrix.budgetExceeded = true;
        matrix.requiredRequests = missingPairs.length;
        matrix.remainingBudget = this.distanceRequestBudgetRemaining;
        return matrix;
      }
      this.distanceRequestBudgetRemaining -= missingPairs.length;
      await this.mapWithConcurrency(missingPairs, CONFIG.distanceConcurrency, async (pair) => {
        const distance = await this.terminalDistance(pair.a, pair.b);
        if (distance != null) matrix.set(pair.key, distance);
      });
      matrix.requestedPairs = missingPairs.length;
      return matrix;
    }

// ===== matrixDistance =====
    matrixDistance(matrix, a, b) {
      if (this.samePhysicalLocation(a, b)) return 0;
      const x = Number(a?.terminalId || 0), y = Number(b?.terminalId || 0);
      if (!(x > 0) || !(y > 0)) return null;
      if (x === y) return 0;
      const value = matrix.get(this.distancePairKey(x, y));
      return value == null ? null : Number(value);
    }

// ===== routeDistance =====
    routeDistance(matrix, locations, start = null, destination = null) {
      const sequence = [];
      if (start?.terminalId) sequence.push(start);
      sequence.push(...locations);
      if (destination?.terminalId) sequence.push(destination);
      let distance = 0, knownSegments = 0, missingSegments = 0;
      for (let i = 1; i < sequence.length; i++) {
        const value = this.matrixDistance(matrix, sequence[i - 1], sequence[i]);
        if (value == null) missingSegments++;
        else { distance += value; knownSegments++; }
      }
      return { distance, knownSegments, missingSegments, complete: missingSegments === 0 };
    }

// ===== exactDistanceOrder =====
    exactDistanceOrder(nodes, matrix, start = null, destination = null) {
      const n = nodes.length;
      if (n <= 1) return { order: nodes.slice(), exact: true };
      const size = 1 << n, inf = Number.POSITIVE_INFINITY,
        dp = Array.from({ length: size }, () => new Float64Array(n).fill(inf)),
        parent = Array.from({ length: size }, () => new Int16Array(n).fill(-1));
      for (let j = 0; j < n; j++) {
        const d = start ? this.matrixDistance(matrix, start, nodes[j]) : 0;
        if (d != null) dp[1 << j][j] = d;
      }
      for (let mask = 1; mask < size; mask++) {
        for (let j = 0; j < n; j++) {
          const current = dp[mask][j];
          if (!Number.isFinite(current) || !(mask & (1 << j))) continue;
          for (let k = 0; k < n; k++) {
            if (mask & (1 << k)) continue;
            const d = this.matrixDistance(matrix, nodes[j], nodes[k]);
            if (d == null) continue;
            const nextMask = mask | (1 << k), value = current + d;
            if (value < dp[nextMask][k]) { dp[nextMask][k] = value; parent[nextMask][k] = j; }
          }
        }
      }
      const full = size - 1;
      let best = inf, endIndex = -1;
      for (let j = 0; j < n; j++) {
        let value = dp[full][j];
        if (!Number.isFinite(value)) continue;
        if (destination) {
          const d = this.matrixDistance(matrix, nodes[j], destination);
          if (d == null) continue;
          value += d;
        }
        if (value < best) { best = value; endIndex = j; }
      }
      if (endIndex < 0) return { order: nodes.slice(), exact: false };
      const indices = [];
      let mask = full, cursor = endIndex;
      while (cursor >= 0) {
        indices.push(cursor);
        const prev = parent[mask][cursor];
        mask ^= 1 << cursor;
        cursor = prev;
      }
      indices.reverse();
      return { order: indices.map((i) => nodes[i]), exact: true, distance: best };
    }

// ===== heuristicDistanceOrder =====
    heuristicDistanceOrder(nodes, matrix, start = null, destination = null) {
      if (nodes.length <= 1) return { order: nodes.slice(), exact: true };
      const candidates = start ? [null] : nodes;
      let bestOrder = nodes.slice(), bestDistance = Number.POSITIVE_INFINITY;
      for (const forcedStart of candidates) {
        const remaining = nodes.slice(), order = [];
        let current = start;
        if (forcedStart) {
          order.push(forcedStart);
          remaining.splice(remaining.indexOf(forcedStart), 1);
          current = forcedStart;
        }
        while (remaining.length) {
          let bestIndex = 0, best = Number.POSITIVE_INFINITY;
          for (let i = 0; i < remaining.length; i++) {
            const d = current ? this.matrixDistance(matrix, current, remaining[i]) : 0;
            const endPenalty = remaining.length === 1 && destination ? this.matrixDistance(matrix, remaining[i], destination) : 0;
            const score = (d == null ? 1e15 : d) + (endPenalty == null ? 1e15 : endPenalty);
            if (score < best) { best = score; bestIndex = i; }
          }
          const next = remaining.splice(bestIndex, 1)[0];
          order.push(next);
          current = next;
        }
        for (let pass = 0; pass < 3; pass++) {
          let improved = false;
          for (let i = 0; i < order.length - 1; i++)
            for (let j = i + 1; j < order.length; j++) {
              const candidate = order.slice();
              candidate.splice(i, j - i + 1, ...candidate.slice(i, j + 1).reverse());
              const before = this.routeDistance(matrix, order, start, destination), after = this.routeDistance(matrix, candidate, start, destination);
              if (after.complete && (!before.complete || after.distance + 1e-9 < before.distance)) {
                order.splice(0, order.length, ...candidate);
                improved = true;
              }
            }
          if (!improved) break;
        }
        const total = this.routeDistance(matrix, order, start, destination);
        if (total.complete && total.distance < bestDistance) { bestDistance = total.distance; bestOrder = order.slice(); }
      }
      return { order: bestOrder, exact: false, distance: bestDistance };
    }

// ===== optimizeCargoPlanDistances =====
    async optimizeCargoPlanDistances(cargoPlan) {
      if (!cargoPlan || this.settings.optimizeDistances === false || !cargoPlan.routeApplied) return cargoPlan;
      const startedAt = performance.now(), beforeStats = { ...this.distanceStats }, trips = cargoPlan.trips || [];
      let totalBefore = 0, totalAfter = 0, completeTrips = 0, reorderedTrips = 0, missingTerminalLocations = 0;
      for (const trip of trips) {
        const origin = trip.route?.start || null, destination = trip.route?.destination || null,
          locations = (trip.locations || []).map((location) => ({ ...location, terminalId: Number(location.terminalIds?.[0] || location.lines?.[0]?.terminalId || 0) || null }));
        missingTerminalLocations += locations.filter((x) => !x.terminalId).length;
        const allNodes = [origin, ...locations, destination].filter((x) => Number(x?.terminalId || 0) > 0);
        if (!locations.length || allNodes.length > CONFIG.distanceMatrixNodeLimit || locations.some((x) => !x.terminalId)) {
          trip.route = { ...trip.route, distanceOptimized: false, distanceDataComplete: false, orderSource: "fallback", distanceFallbackReason: locations.some((x) => !x.terminalId) ? "missing-terminal-id" : allNodes.length > CONFIG.distanceMatrixNodeLimit ? "matrix-node-limit" : "no-location" };
          continue;
        }
        const matrix = await this.terminalDistanceMatrix(allNodes);
        if (matrix.budgetExceeded) {
          trip.route = { ...trip.route, distanceOptimized: false, distanceDataComplete: false, orderSource: "fallback", distanceFallbackReason: "request-budget", distanceRequiredRequests: matrix.requiredRequests, distanceRemainingBudget: matrix.remainingBudget };
          continue;
        }
        const original = this.routeDistance(matrix, locations, origin, destination),
          systemOrder = trip.route?.pickupSystemOrder?.length ? trip.route.pickupSystemOrder : unique(locations.map((x) => x.system));
        let previous = origin, ordered = [], exact = true;
        for (let systemIndex = 0; systemIndex < systemOrder.length; systemIndex++) {
          const system = systemOrder[systemIndex], group = locations.filter((x) => x.system === system),
            end = systemIndex === systemOrder.length - 1 ? destination : null,
            solved = group.length <= CONFIG.distanceExactLimit
              ? this.exactDistanceOrder(group, matrix, previous, end)
              : this.heuristicDistanceOrder(group, matrix, previous, end);
          exact &&= Boolean(solved.exact);
          ordered.push(...solved.order);
          previous = solved.order.at(-1) || previous;
        }
        const optimized = this.routeDistance(matrix, ordered, origin, destination), changed = ordered.some((x, i) => x.key !== locations[i]?.key);
        trip.locations = ordered.map((location, index) => ({ ...location, routeOrder: index + 1, isRouteOrigin: Boolean(origin?.key && location.key === origin.key), isRouteDestination: Boolean(destination?.key && location.key === destination.key) }));
        trip.route = {
          ...trip.route,
          distanceOptimized: optimized.complete,
          distanceDataComplete: optimized.complete,
          orderSource: optimized.complete ? (exact ? "uex-exact" : "uex-heuristic") : "fallback",
          distanceMethod: exact ? "held-karp-system-groups" : "nearest-neighbor-2opt-system-groups",
          originalDistanceGm: original.complete ? original.distance : null,
          estimatedDistanceGm: optimized.complete ? optimized.distance : null,
          distanceSavedGm: original.complete && optimized.complete ? Math.max(0, original.distance - optimized.distance) : null,
          orderChangedByDistance: changed,
          exactWithinSystemGroups: exact,
          distanceKnownUnavailablePairs: Number(matrix.knownUnavailablePairs || 0),
          distanceSameLocationZeroPairs: Number(matrix.sameLocationZeroPairs || 0),
          distanceRequestedPairs: Number(matrix.requestedPairs || 0),
          distanceFallbackReason: optimized.complete ? null : "missing-distance-pair",
        };
        if (original.complete) totalBefore += original.distance;
        if (optimized.complete) {
          totalAfter += optimized.distance;
          completeTrips++;
        }
        if (optimized.complete && changed) reorderedTrips++;
      }
      const tripCount = trips.length,
        exactTrips = trips.filter((trip) => trip.route?.distanceOptimized && trip.route?.orderSource === "uex-exact").length,
        heuristicTrips = trips.filter((trip) => trip.route?.distanceOptimized && trip.route?.orderSource === "uex-heuristic").length,
        fallbackTrips = Math.max(0, tripCount - exactTrips - heuristicTrips),
        allTripsComplete = completeTrips === tripCount && completeTrips > 0;
      cargoPlan.distanceOptimized = allTripsComplete;
      cargoPlan.navigationOptimized = allTripsComplete;
      cargoPlan.estimatedDistanceGm = allTripsComplete ? totalAfter : null;
      cargoPlan.originalDistanceGm = allTripsComplete ? totalBefore : null;
      cargoPlan.distanceSavedGm = allTripsComplete ? Math.max(0, totalBefore - totalAfter) : null;
      cargoPlan.partialEstimatedDistanceGm = completeTrips ? totalAfter : null;
      cargoPlan.partialOriginalDistanceGm = completeTrips ? totalBefore : null;
      cargoPlan.distanceDataComplete = allTripsComplete;
      cargoPlan.distanceTripCount = tripCount;
      cargoPlan.distanceOptimizedTrips = completeTrips;
      cargoPlan.distanceExactTrips = exactTrips;
      cargoPlan.distanceHeuristicTrips = heuristicTrips;
      cargoPlan.distanceFallbackTrips = fallbackTrips;
      cargoPlan.distanceReorderedTrips = reorderedTrips;
      cargoPlan.distanceSameLocationZeroPairs = trips.reduce(
        (sum, trip) => sum + Number(trip.route?.distanceSameLocationZeroPairs || 0),
        0,
      );
      cargoPlan.missingTerminalLocations = missingTerminalLocations;
      cargoPlan.distanceMethod = allTripsComplete
        ? heuristicTrips
          ? "uex-terminals-distances-mixed-exact-heuristic-v4"
          : "uex-terminals-distances-exact-system-groups-v4"
        : completeTrips
          ? "uex-terminals-distances-partial-v4"
          : "system-body-place-fallback-v3";
      cargoPlan.distancePerformanceMs = Math.round((performance.now() - startedAt) * 10) / 10;
      cargoPlan.distanceApi = {};
      for (const key of Object.keys(this.distanceStats))
        cargoPlan.distanceApi[key] = Number(this.distanceStats[key] || 0) - Number(beforeStats[key] || 0);
      await this.saveDistanceCache();
      return cargoPlan;
    }

// ===== orderCargoLocations =====
    orderCargoLocations(locations, start, destination) {
      const bodyKey = (location) =>
          text(location?.body).trim() || text(location?.place).trim() || "Ismeretlen bolygócsoport",
        groups = new Map();
      for (const location of locations) {
        const system = location.system || "Ismeretlen rendszer";
        if (!groups.has(system)) groups.set(system, new Map());
        const bodies = groups.get(system), body = bodyKey(location);
        if (!bodies.has(body)) bodies.set(body, []);
        bodies.get(body).push(location);
      }
      const startSystem = start?.system || "", destinationSystem = destination?.system || "",
        systems = [...groups.keys()].sort((a, b) => a.localeCompare(b, "hu")),
        orderedSystems = [];
      if (startSystem && groups.has(startSystem)) orderedSystems.push(startSystem);
      for (const system of systems)
        if (system !== startSystem && system !== destinationSystem) orderedSystems.push(system);
      if (destinationSystem && groups.has(destinationSystem) && !orderedSystems.includes(destinationSystem))
        orderedSystems.push(destinationSystem);
      for (const system of systems) if (!orderedSystems.includes(system)) orderedSystems.push(system);

      const result = [];
      for (const system of orderedSystems) {
        const bodyGroups = groups.get(system),
          startBody = start?.system === system ? bodyKey(start) : "",
          destinationBody = destination?.system === system ? bodyKey(destination) : "",
          bodies = [...bodyGroups.keys()].sort((a, b) => a.localeCompare(b, "hu")),
          orderedBodies = [];
        if (startBody && bodyGroups.has(startBody)) orderedBodies.push(startBody);
        for (const body of bodies)
          if (body !== startBody && body !== destinationBody) orderedBodies.push(body);
        if (destinationBody && bodyGroups.has(destinationBody) && !orderedBodies.includes(destinationBody))
          orderedBodies.push(destinationBody);
        for (const body of bodies) if (!orderedBodies.includes(body)) orderedBodies.push(body);

        for (const body of orderedBodies) {
          const rows = bodyGroups.get(body).slice().sort((a, b) => {
            const aOrigin = start?.key && a.key === start.key ? -1 : 0,
              bOrigin = start?.key && b.key === start.key ? -1 : 0,
              aDestination = destination?.key && a.key === destination.key ? 1 : 0,
              bDestination = destination?.key && b.key === destination.key ? 1 : 0;
            return (aOrigin - bOrigin) || (aDestination - bDestination) ||
              a.place.localeCompare(b.place, "hu") || a.key.localeCompare(b.key, "hu");
          });
          result.push(...rows);
        }
      }
      return result;
    }

// ===== buildCargoPlan =====
    buildCargoPlan(plan, ship, routeContext = null) {
      const capacity = Number(ship?.scu || 0),
        totalPurchased = Number(plan?.totalQty || 0),
        EPS = 1e-6;
      if (!plan || !(capacity > 0) || !(totalPurchased > 0) || !plan.places?.length)
        return null;
      const makeTrip = () => ({
          index: 0,
          capacity,
          load: 0,
          free: capacity,
          cost: 0,
          systems: new Set(),
          locations: new Map(),
        }),
        theoreticalMinTurns = Math.max(1, Math.ceil((totalPurchased - EPS) / capacity)),
        trips = Array.from({ length: theoreticalMinTurns }, makeTrip),
        bundles = (plan.places || [])
          .map((place) => ({
            key: place.key || place.physicalLocationKey || `${place.system}|${place.place}`,
            system: place.system || "Ismeretlen rendszer",
            body: place.body || "",
            place: place.place || "Ismeretlen hely",
            locationType: place.locationType || "other",
            total: Number(place.quantity ?? place.purchasedQuantity ?? 0),
            cost: Number(place.cost || 0),
            lines: (place.lines || []).map((line, index) => {
              const purchased = Number(line.purchasedQuantity ?? line.quantity ?? 0),
                covered = Number(line.coveredQuantity ?? line.quantity ?? purchased),
                groups = (line.containerCombination || [])
                  .map((c) => ({ size: Number(c.size || 0), count: Math.max(0, Math.floor(Number(c.count || 0))) }))
                  .filter((c) => c.size > 0 && c.count > 0)
                  .sort((a, b) => b.size - a.size),
                groupedQty = groups.reduce((sum, c) => sum + c.size * c.count, 0);
              return {
                key: `${line.commodityId}|${line.terminalId}|${index}`,
                commodityId: Number(line.commodityId),
                commodityName: line.commodityName || "Ismeretlen commodity",
                terminalId: line.terminalId,
                terminalName: line.terminalName || "Ismeretlen terminál",
                providerId: line.providerId || "uex",
                unitPrice: Number(line.price || 0),
                purchased,
                covered,
                overbuy: Math.max(0, purchased - covered),
                groups,
                flexibleQty: Math.max(0, purchased - groupedQty),
                containerKnown: Boolean(line.containerKnown && groups.length),
                coveredRemaining: covered,
              };
            }),
          }))
          .filter((bundle) => bundle.total > EPS)
          .sort((a, b) => b.total - a.total || a.system.localeCompare(b.system, "hu") || a.place.localeCompare(b.place, "hu"));
      const ensureTrip = () => {
          const trip = makeTrip();
          trips.push(trip);
          return trip;
        },
        getLocation = (trip, bundle) => {
          if (!trip.locations.has(bundle.key))
            trip.locations.set(bundle.key, {
              key: bundle.key,
              system: bundle.system,
              body: bundle.body,
              place: bundle.place,
              locationType: bundle.locationType,
              quantity: 0,
              cost: 0,
              lines: new Map(),
            });
          return trip.locations.get(bundle.key);
        },
        addPortion = (trip, bundle, line, qty, containers = [], estimated = false) => {
          qty = Number(qty || 0);
          if (!(qty > EPS)) return;
          const location = getLocation(trip, bundle),
            lineKey = `${line.commodityId}|${line.terminalId}`;
          if (!location.lines.has(lineKey))
            location.lines.set(lineKey, {
              commodityId: line.commodityId,
              commodityName: line.commodityName,
              terminalId: line.terminalId,
              terminalName: line.terminalName,
              providerId: line.providerId,
              unitPrice: line.unitPrice,
              quantity: 0,
              coveredQuantity: 0,
              overbuyQuantity: 0,
              cost: 0,
              estimated: false,
              containers: new Map(),
            });
          const row = location.lines.get(lineKey),
            coveredTake = Math.min(Math.max(0, line.coveredRemaining), qty),
            overbuyTake = Math.max(0, qty - coveredTake),
            cost = qty * line.unitPrice;
          line.coveredRemaining = Math.max(0, line.coveredRemaining - coveredTake);
          row.quantity += qty;
          row.coveredQuantity += coveredTake;
          row.overbuyQuantity += overbuyTake;
          row.cost += cost;
          row.estimated ||= estimated;
          for (const c of containers) {
            const size = Number(c.size || 0), count = Number(c.count || 0);
            if (size > 0 && count > 0)
              row.containers.set(size, (row.containers.get(size) || 0) + count);
          }
          location.quantity += qty;
          location.cost += cost;
          trip.load += qty;
          trip.cost += cost;
          trip.free = Math.max(0, capacity - trip.load);
          trip.systems.add(bundle.system);
        },
        tripScore = (trip, bundle, required) => {
          const sameLocation = trip.locations.has(bundle.key) ? 0 : 1,
            sameSystem = !trip.systems.size || trip.systems.has(bundle.system) ? 0 : 1,
            leftover = trip.free - required;
          return [sameLocation, sameSystem, leftover, trip.load];
        },
        compareScore = (a, b) => {
          for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return a[i] - b[i];
          return 0;
        },
        bestTrip = (bundle, required, allowEmpty = true) => {
          const candidates = trips.filter((trip) => trip.free + EPS >= required && (allowEmpty || trip.load > EPS));
          return candidates.sort((a, b) => compareScore(tripScore(a, bundle, required), tripScore(b, bundle, required)))[0] || null;
        },
        addWholeBundle = (trip, bundle) => {
          for (const line of bundle.lines) {
            const containers = line.groups.map((g) => ({ size: g.size, count: g.count }));
            addPortion(trip, bundle, line, line.purchased, containers, line.flexibleQty > EPS);
          }
        },
        splitBundle = (bundle) => {
          for (const line of bundle.lines) {
            for (const group of line.groups) {
              let count = group.count;
              while (count > 0) {
                let trip = bestTrip(bundle, group.size);
                if (!trip) trip = ensureTrip();
                const take = Math.min(count, Math.floor((trip.free + EPS) / group.size));
                if (!(take > 0)) {
                  trip = ensureTrip();
                  continue;
                }
                addPortion(trip, bundle, line, take * group.size, [{ size: group.size, count: take }], false);
                count -= take;
              }
            }
            let flexible = line.flexibleQty;
            while (flexible > EPS) {
              let candidates = trips.filter((trip) => trip.free > EPS);
              candidates.sort((a, b) => compareScore(tripScore(a, bundle, Math.min(flexible, a.free)), tripScore(b, bundle, Math.min(flexible, b.free))));
              let trip = candidates[0] || ensureTrip();
              const take = Math.min(flexible, trip.free);
              if (!(take > EPS)) {
                trip = ensureTrip();
                continue;
              }
              addPortion(trip, bundle, line, take, [], true);
              flexible -= take;
            }
          }
        };
      const oversized = bundles.filter((bundle) => bundle.total > capacity + EPS),
        regular = bundles.filter((bundle) => bundle.total <= capacity + EPS);
      for (const bundle of oversized) splitBundle(bundle);
      for (const bundle of regular) {
        const trip = bestTrip(bundle, bundle.total);
        if (trip) addWholeBundle(trip, bundle);
        else splitBundle(bundle);
      }
      const baseTrips = trips
        .filter((trip) => trip.load > EPS)
        .map((trip, index) => {
          const locations = [...trip.locations.values()]
            .map((location) => ({
              ...location,
              lines: [...location.lines.values()]
                .map((line) => ({
                  ...line,
                  containers: [...line.containers.entries()]
                    .map(([size, count]) => ({ size: Number(size), count }))
                    .sort((a, b) => b.size - a.size),
                }))
                .sort((a, b) => a.commodityName.localeCompare(b.commodityName, "hu")),
            }))
            .sort((a, b) => a.system.localeCompare(b.system, "hu") || a.place.localeCompare(b.place, "hu"));
          return {
            index: index + 1,
            capacity,
            load: trip.load,
            free: Math.max(0, capacity - trip.load),
            utilization: capacity > 0 ? trip.load / capacity : 0,
            cost: trip.cost,
            systems: [...trip.systems].sort((a, b) => a.localeCompare(b, "hu")),
            locations,
          };
        });
      const routeResult = this.applyCargoRouteOrdering(baseTrips, routeContext || this.currentRouteContext()),
        normalizedTrips = routeResult.trips;
      const visits = new Map();
      for (const trip of normalizedTrips)
        for (const location of trip.locations)
          visits.set(location.key, (visits.get(location.key) || 0) + 1);
      const bundleByKey = new Map(bundles.map((b) => [b.key, b]));
      const repeatedLocations = [...visits.entries()]
        .filter(([, count]) => count > 1)
        .map(([key, count]) => {
          const bundle = bundleByKey.get(key);
          return {
            key,
            system: bundle?.system || "",
            place: bundle?.place || key,
            visits: count,
            quantity: Number(bundle?.total || 0),
            unavoidableByCapacity: Number(bundle?.total || 0) > capacity + EPS,
          };
        });
      const assignedQuantity = normalizedTrips.reduce((sum, trip) => sum + trip.load, 0),
        assignedCost = normalizedTrips.reduce((sum, trip) => sum + trip.cost, 0),
        actualTurns = normalizedTrips.length,
        containerExact = bundles.every((bundle) => bundle.lines.every((line) => line.flexibleQty <= EPS));
      return {
        shipId: ship.id,
        shipName: ship.name,
        capacity,
        theoreticalMinTurns,
        tripCount: actualTurns,
        extraTurnsDueToPacking: Math.max(0, actualTurns - theoreticalMinTurns),
        totalPurchased,
        assignedQuantity,
        quantityMatches: Math.abs(assignedQuantity - totalPurchased) < 1e-6,
        totalCost: Number(plan.totalCost || 0),
        assignedCost,
        costMatches: Math.abs(assignedCost - Number(plan.totalCost || 0)) < 0.01,
        totalFree: actualTurns * capacity - assignedQuantity,
        lastTripFree: normalizedTrips.length ? normalizedTrips.at(-1).free : 0,
        utilization: actualTurns > 0 ? assignedQuantity / (actualTurns * capacity) : 0,
        containerExact,
        repeatedLocationCount: repeatedLocations.length,
        avoidableRepeatedLocationCount: repeatedLocations.filter((x) => !x.unavoidableByCapacity).length,
        repeatedLocations,
        complete: Boolean(plan.complete),
        requestedQuantity: Number(plan.requestedQty || 0),
        coveredQuantity: Number(plan.coveredQty || 0),
        missingQuantity: Math.max(0, Number(plan.requestedQty || 0) - Number(plan.coveredQty || 0)),
        routeApplied: routeResult.applied,
        routeOrigin: routeResult.origin,
        routeDestination: routeResult.destination,
        systemTransitions: routeResult.totalSystemTransitions,
        navigationOptimized: false,
        systemOrderOptimized: routeResult.applied,
        distanceOptimized: false,
        distanceDataComplete: false,
        distanceTripCount: routeResult.applied ? actualTurns : 0,
        distanceOptimizedTrips: 0,
        distanceExactTrips: 0,
        distanceHeuristicTrips: 0,
        distanceFallbackTrips: routeResult.applied ? actualTurns : 0,
        distanceReorderedTrips: 0,
        distanceApi: clone(this.distanceStats),
        distanceApiCalculation: clone(this.distanceStats),
        distanceMethod: routeResult.applied ? "system-body-place-fallback-v2" : null,
        method: routeResult.method,
        trips: normalizedTrips,
      };
    }
}
