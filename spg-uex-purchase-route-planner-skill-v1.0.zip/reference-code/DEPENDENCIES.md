# Shared dependencies

The extracts expect helper functions and state such as `text`, `num`, `bool`, `lower`, `unique`, `clone`, `nowIso`, `fmtQty`, stable signatures, CONFIG values, storage, logger, API client, current route context and cargo-plan objects.

Do not invent replacements silently. Map each dependency to the target project and add fixture tests before changing algorithmic behavior. The canonical dependency definitions are in `reference-app/sPg UEX Vásárlás V1.0.36.html`.
