# Reference code

These files are exact or near-exact extracts from `sPg UEX Vásárlás V1.0.36`.

- `Planner.js`: container, stock and basket optimization.
- `UexNormalizer.js`: UEX record normalization.
- `ApiClient.js`: browser API fallback, retry and timeout.
- `ProviderRegistry.js`: Provider Contract v2.
- `distance-routing-methods.js`: App-class distance and cargo route methods wrapped in a reference class for syntax validity.

They are not a drop-in package. The target project must provide the shared helpers, state, storage, logger and UI-independent I/O. Preserve the behavior described in `references/UEX_LOGIC_SPEC.md`. Use the full reference app only when a missing dependency must be traced exactly.
